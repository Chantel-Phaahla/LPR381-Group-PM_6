using System.Windows;

namespace Solve.UI
{
    /// <summary>
    /// WPF application entry point. Intentionally empty - startup is declared
    /// via StartupUri in App.xaml, and all real logic lives in MainWindow.
    /// </summary>
    public partial class App : Application
    {
    }
}
