namespace Solve.Models
{
    /// <summary>
    /// Whether the objective function must be maximised or minimised.
    /// </summary>
    public enum ObjectiveSense
    {
        Maximize,
        Minimize
    }

    /// <summary>
    /// The relation used on the right-hand-side of a constraint.
    /// </summary>
    public enum RelationType
    {
        LessOrEqual,    // <=
        GreaterOrEqual, // >=
        Equal           // =
    }

    /// <summary>
    /// Sign restriction placed on a decision variable, as read from the
    /// last line of the input file (+, -, urs, int, bin).
    /// </summary>
    public enum VariableRestriction
    {
        Positive,      // +      : x >= 0
        Negative,      // -      : x <= 0
        Unrestricted,  // urs    : x free in sign
        Integer,       // int    : x >= 0 and integer
        Binary         // bin    : x in {0,1}
    }

    /// <summary>
    /// Outcome of an attempt to solve a model.
    /// </summary>
    public enum SolutionStatus
    {
        NotSolved,
        Optimal,
        Infeasible,
        Unbounded
    }
}
