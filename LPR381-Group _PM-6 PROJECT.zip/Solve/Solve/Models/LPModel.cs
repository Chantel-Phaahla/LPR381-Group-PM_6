using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Solve.Models
{
    /// <summary>
    /// Full in-memory representation of a Linear Programming / Integer Programming
    /// model, exactly as read from the input text file (i.e. NOT a canonical or
    /// standard form - that conversion happens inside the individual solvers).
    /// </summary>
    public class LPModel
    {
        public ObjectiveSense Sense { get; set; }

        /// <summary>Objective function coefficients c1..cn (signed).</summary>
        public List<double> ObjectiveCoefficients { get; }

        public List<Constraint> Constraints { get; }

        /// <summary>Sign restriction for each decision variable, x1..xn.</summary>
        public List<VariableRestriction> SignRestrictions { get; }

        /// <summary>Optional human-readable variable names (x1, x2, ...) used purely for display.</summary>
        public List<string> VariableNames { get; }

        public int VariableCount => ObjectiveCoefficients.Count;

        public bool HasIntegerRestrictions =>
            SignRestrictions.Any(r => r == VariableRestriction.Integer || r == VariableRestriction.Binary);

        public bool HasBinaryRestrictions =>
            SignRestrictions.Any(r => r == VariableRestriction.Binary);

        public LPModel(ObjectiveSense sense,
                        List<double> objectiveCoefficients,
                        List<Constraint> constraints,
                        List<VariableRestriction> signRestrictions)
        {
            Sense = sense;
            ObjectiveCoefficients = objectiveCoefficients;
            Constraints = constraints;
            SignRestrictions = signRestrictions;
            VariableNames = Enumerable.Range(1, objectiveCoefficients.Count)
                                       .Select(i => $"x{i}")
                                       .ToList();
        }

        /// <summary>Deep copy - required because Branch &amp; Bound / Cutting Plane
        /// repeatedly derive new sub-problems from a parent model.</summary>
        public LPModel Clone()
        {
            var clonedConstraints = Constraints.Select(c => c.Clone()).ToList();
            var clone = new LPModel(
                Sense,
                new List<double>(ObjectiveCoefficients),
                clonedConstraints,
                new List<VariableRestriction>(SignRestrictions));
            return clone;
        }

        /// <summary>
        /// Renders the model back out exactly as it was supplied, i.e. the
        /// "Linear/Integer Programming Model" (NOT canonical form). Useful for
        /// echoing the parsed model back to the user for confirmation.
        /// </summary>
        public string ToDisplayString()
        {
            var sb = new StringBuilder();
            sb.Append(Sense == ObjectiveSense.Maximize ? "max " : "min ");
            sb.AppendLine(string.Join(" ", ObjectiveCoefficients.Select((c, i) => $"{Fmt(c)}{VariableNames[i]}")));

            foreach (var c in Constraints)
            {
                var terms = string.Join(" ", c.Coefficients.Select((coef, i) => $"{Fmt(coef)}{VariableNames[i]}"));
                sb.AppendLine($"{terms} {c.RelationSymbol} {Round(c.Rhs)}");
            }

            sb.AppendLine(string.Join(" ", SignRestrictions.Select(RestrictionToken)));
            return sb.ToString();
        }

        private static string Fmt(double v) => v >= 0 ? $"+{Round(v)}" : Round(v).ToString();

        private static double Round(double v) => Math.Round(v, 3);

        private static string RestrictionToken(VariableRestriction r) => r switch
        {
            VariableRestriction.Positive => "+",
            VariableRestriction.Negative => "-",
            VariableRestriction.Unrestricted => "urs",
            VariableRestriction.Integer => "int",
            VariableRestriction.Binary => "bin",
            _ => "?"
        };
    }
}
