using System.Collections.Generic;

namespace Solve.Models
{
    /// <summary>
    /// Represents a single constraint of the linear/integer programming model:
    ///     a1*x1 + a2*x2 + ... + an*xn  {&lt;=, &gt;=, =}  b
    /// </summary>
    public class Constraint
    {
        /// <summary>Technological coefficients, in the same order as the objective function.</summary>
        public List<double> Coefficients { get; }

        /// <summary>The relational operator used by this constraint.</summary>
        public RelationType Relation { get; set; }

        /// <summary>Right-hand-side value of the constraint.</summary>
        public double Rhs { get; set; }

        public Constraint(List<double> coefficients, RelationType relation, double rhs)
        {
            Coefficients = coefficients;
            Relation = relation;
            Rhs = rhs;
        }

        /// <summary>Creates an independent copy of this constraint (used heavily by
        /// Branch &amp; Bound / Cutting Plane, which must branch on copies of the model).</summary>
        public Constraint Clone()
        {
            return new Constraint(new List<double>(Coefficients), Relation, Rhs);
        }

        public string RelationSymbol => Relation switch
        {
            RelationType.LessOrEqual => "<=",
            RelationType.GreaterOrEqual => ">=",
            RelationType.Equal => "=",
            _ => "?"
        };
    }
}
