using System;

namespace Solve.Models
{
    /// <summary>
    /// Uniform result object returned by every algorithm (Primal Simplex,
    /// Revised Simplex, Branch &amp; Bound, Cutting Plane, Knapsack B&amp;B, ...)
    /// so that the menu / output layer never needs to know which algorithm
    /// actually produced the answer.
    /// </summary>
    public class SolveResult
    {
        public SolutionStatus Status { get; set; } = SolutionStatus.NotSolved;

        /// <summary>Final value of each original decision variable, x1..xn.</summary>
        public double[] VariableValues { get; set; } = Array.Empty<double>();

        /// <summary>Final objective function value (in the ORIGINAL max/min sense of the model).</summary>
        public double ObjectiveValue { get; set; }

        /// <summary>Free-text explanation, e.g. reason for infeasibility/unboundedness.</summary>
        public string Message { get; set; } = string.Empty;

        /// <summary>The name of the algorithm that produced this result.</summary>
        public string AlgorithmName { get; set; } = string.Empty;

        /// <summary>
        /// Optional handle back to the last optimal simplex tableau, kept so that the
        /// Sensitivity Analysis module can operate on it without re-solving.
        /// </summary>
        public object? FinalTableau { get; set; }

        public static SolveResult Infeasible(string algorithm, string reason) => new()
        {
            Status = SolutionStatus.Infeasible,
            AlgorithmName = algorithm,
            Message = reason
        };

        public static SolveResult Unbounded(string algorithm, string reason) => new()
        {
            Status = SolutionStatus.Unbounded,
            AlgorithmName = algorithm,
            Message = reason
        };
    }
}
