using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Win32;
using Solve.IO;
using Solve.Models;
using Solve.SensitivityAnalysis;
using Solve.Solvers;

namespace Solve.UI
{
    /// <summary>Simple row shown in the variable-values DataGrid.</summary>
    public class VariableRow
    {
        public string Name { get; set; } = string.Empty;
        public string Value { get; set; } = string.Empty;
    }

    /// <summary>
    /// Code-behind for the desktop application shell. Everything below is UI
    /// glue only - all the actual parsing/solving/sensitivity logic lives
    /// untouched in the IO/, Solvers/ and SensitivityAnalysis/ namespaces, so
    /// this class simply calls into that backend and renders the results.
    /// </summary>
    public partial class MainWindow : Window
    {
        private LPModel? _model;
        private SolveResult? _lastResult;
        private string _outputPath = "output.txt";

        private readonly List<ISolver> _solvers = new()
        {
            new PrimalSimplexSolver(),
            new RevisedSimplexSolver(),
            new BranchAndBoundSolver(),
            new CuttingPlaneSolver(),
            new KnapsackBranchAndBoundSolver(),
        };

        private const string KnapsackExample = "max +2 +3 +3 +5 +2 +4\n+11 +8 +6 +14 +10 +10 <=40\nbin bin bin bin bin bin\n";

        public MainWindow()
        {
            InitializeComponent();

            // Set the initial nav selection AFTER InitializeComponent() has finished
            // wiring up every named element, so Nav_Checked (fired as a side effect
            // of setting IsChecked) can safely reference every panel it toggles.
            NavDashboard.IsChecked = true;

            TxtOutputFileHint.Text = _outputPath;
            BuildAlgorithmList();
            BuildSensitivityList();
        }

        // =====================================================================
        // Navigation
        // =====================================================================

        private void Nav_Checked(object sender, RoutedEventArgs e)
        {
            if (sender is not RadioButton rb) return;
            string tag = rb.Tag?.ToString() ?? "Dashboard";

            // Defensive guard: InitializeComponent() connects named fields in XAML
            // document order, so if this handler is ever invoked before every panel
            // below has been assigned (e.g. a future edit re-adds IsChecked="True"
            // to a RadioButton declared before them), bail out instead of crashing
            // with a NullReferenceException.
            if (PanelDashboard is null || PanelLoad is null || PanelSolve is null ||
                PanelSensitivity is null || PanelSettings is null) return;

            PanelDashboard.Visibility = tag == "Dashboard" ? Visibility.Visible : Visibility.Collapsed;
            PanelLoad.Visibility = tag == "Load" ? Visibility.Visible : Visibility.Collapsed;
            PanelSolve.Visibility = tag == "Solve" ? Visibility.Visible : Visibility.Collapsed;
            PanelSensitivity.Visibility = tag == "Sensitivity" ? Visibility.Visible : Visibility.Collapsed;
            PanelSettings.Visibility = tag == "Settings" ? Visibility.Visible : Visibility.Collapsed;
        }

        private void GoToLoad_Click(object sender, RoutedEventArgs e) => NavLoad.IsChecked = true;

        // =====================================================================
        // Load model
        // =====================================================================

        private void Browse_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog { Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*" };
            if (dialog.ShowDialog() == true)
                TxtInputPath.Text = dialog.FileName;
        }

        private void LoadButton_Click(object sender, RoutedEventArgs e)
        {
            string path = TxtInputPath.Text.Trim();
            if (string.IsNullOrWhiteSpace(path))
            {
                ShowLoadStatus(false, "Please enter or browse to an input file path.");
                return;
            }

            try
            {
                var model = InputParser.ParseFile(path);
                ApplyLoadedModel(model, $"Model loaded successfully from '{Path.GetFileName(path)}'.");
            }
            catch (ModelInputException ex)
            {
                ShowLoadStatus(false, ex.Message);
            }
            catch (Exception ex)
            {
                ShowLoadStatus(false, $"An unexpected error occurred while loading the file: {ex.Message}");
            }
        }

        private void LoadExample_Click(object sender, RoutedEventArgs e)
        {
            NavLoad.IsChecked = true;
            try
            {
                var model = InputParser.ParseText(KnapsackExample);
                TxtInputPath.Text = "(bundled Knapsack example)";
                ApplyLoadedModel(model, "Bundled Knapsack example loaded.");
            }
            catch (ModelInputException ex)
            {
                ShowLoadStatus(false, ex.Message);
            }
        }

        private void ApplyLoadedModel(LPModel model, string successMessage)
        {
            _model = model;
            _lastResult = null;

            TxtModelPreview.Text = model.ToDisplayString();
            ShowLoadStatus(true, successMessage);
            ResetResultSummary();
            RefreshDashboard();

            ModelStatusDot.Fill = new SolidColorBrush(Color.FromRgb(0x1E, 0x9E, 0x64));
            TxtModelStatus.Text = $"{model.VariableCount} variable(s), {model.Constraints.Count} constraint(s) loaded";
        }

        private void ShowLoadStatus(bool success, string message)
        {
            LoadStatusBanner.Visibility = Visibility.Visible;
            LoadStatusBanner.Background = (Brush)FindResource(success ? "SuccessBgBrush" : "ErrorBgBrush");
            TxtLoadStatus.Foreground = (Brush)FindResource(success ? "SuccessBrush" : "ErrorBrush");
            TxtLoadStatus.Text = message;
        }

        private void RefreshDashboard()
        {
            if (_model is null)
            {
                TxtDashSense.Text = "—";
                TxtDashVars.Text = "—";
                TxtDashConstraints.Text = "—";
                TxtDashIntFlag.Text = "—";
                return;
            }

            TxtDashSense.Text = _model.Sense == ObjectiveSense.Maximize ? "Maximize" : "Minimize";
            TxtDashVars.Text = _model.VariableCount.ToString();
            TxtDashConstraints.Text = _model.Constraints.Count.ToString();
            TxtDashIntFlag.Text = _model.HasIntegerRestrictions ? "Yes" : "No";
        }

        // =====================================================================
        // Solve
        // =====================================================================

        private void BuildAlgorithmList()
        {
            AlgorithmList.Children.Clear();
            foreach (var solver in _solvers)
            {
                var button = new Button
                {
                    Style = (Style)FindResource("OptionCardButton"),
                    Tag = solver
                };

                var stack = new StackPanel();
                stack.Children.Add(new TextBlock
                {
                    Text = solver.Name,
                    FontWeight = FontWeights.SemiBold,
                    FontSize = 14
                });
                stack.Children.Add(new TextBlock
                {
                    Text = DescriptionFor(solver),
                    Style = (Style)FindResource("BodyText"),
                    Margin = new Thickness(0, 4, 0, 0)
                });
                button.Content = stack;
                button.Click += (_, _) => RunSolver(solver);

                AlgorithmList.Children.Add(button);
            }
        }

        private static string DescriptionFor(ISolver solver) => solver switch
        {
            PrimalSimplexSolver => "Big-M tableau method for a plain LP. Displays the canonical form and every iteration.",
            CuttingPlaneSolver => "Solves the LP relaxation, then adds Gomory cuts until every integer/binary variable is integral.",
            RevisedSimplexSolver => "Solves via a basis inverse (B\u207B\u00B9), logging Price-Out and Product Form iterations instead of a full tableau.",
            BranchAndBoundSolver => "Branches on fractional integer/binary variables, solving each sub-problem's LP relaxation with full backtracking and fathoming.",
            KnapsackBranchAndBoundSolver => "Classic ratio-sorted Branch & Bound for single-constraint, maximising 0/1 Knapsack models.",
            _ => string.Empty
        };

        private async void RunSolver(ISolver solver)
        {
            if (_model is null)
            {
                MessageBox.Show(this, "Load a model first.", "No model loaded", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            SetAlgorithmButtonsEnabled(false);
            LogBox.Clear();
            TxtModelStatus.Text = $"Running {solver.Name}...";

            var log = new ResultLogger(echoToConsole: false);
            log.LineWritten += line => Dispatcher.Invoke(() => AppendLog(line));

            SolveResult result;
            try
            {
                result = await System.Threading.Tasks.Task.Run(() => solver.Solve(_model!, log));
            }
            catch (Exception ex)
            {
                AppendLog($"[ERROR] {ex.Message}");
                result = new SolveResult { Status = SolutionStatus.NotSolved, AlgorithmName = solver.Name, Message = ex.Message };
            }

            _lastResult = result;
            UpdateResultSummary(result);

            try
            {
                log.FlushToFile(_outputPath, append: true);
            }
            catch (IOException ex)
            {
                AppendLog($"[ERROR] Could not write to output file: {ex.Message}");
            }

            TxtModelStatus.Text = $"{_model.VariableCount} variable(s), {_model.Constraints.Count} constraint(s) loaded";
            SetAlgorithmButtonsEnabled(true);
        }

        private void SetAlgorithmButtonsEnabled(bool enabled)
        {
            foreach (var child in AlgorithmList.Children)
                if (child is Button b) b.IsEnabled = enabled;
        }

        private void AppendLog(string line)
        {
            LogBox.AppendText(line + Environment.NewLine);
            LogBox.ScrollToEnd();
        }

        private void UpdateResultSummary(SolveResult result)
        {
            TxtAlgorithmUsed.Text = result.AlgorithmName;

            (string label, Brush fg, Brush bg) = result.Status switch
            {
                SolutionStatus.Optimal => ("OPTIMAL", (Brush)FindResource("SuccessBrush"), (Brush)FindResource("SuccessBgBrush")),
                SolutionStatus.Infeasible => ("INFEASIBLE", (Brush)FindResource("ErrorBrush"), (Brush)FindResource("ErrorBgBrush")),
                SolutionStatus.Unbounded => ("UNBOUNDED", (Brush)FindResource("WarningBrush"), (Brush)FindResource("WarningBgBrush")),
                _ => ("NOT SOLVED", (Brush)FindResource("TextSecondaryBrush"), (Brush)FindResource("BorderBrush2"))
            };
            TxtStatus.Text = label;
            TxtStatus.Foreground = fg;
            StatusBadge.Background = bg;

            if (result.Status == SolutionStatus.Optimal)
            {
                TxtObjectiveValue.Text = ResultLogger.Fmt(result.ObjectiveValue);
                var rows = new List<VariableRow>();
                for (int i = 0; i < result.VariableValues.Length; i++)
                {
                    string name = _model != null && i < _model.VariableNames.Count ? _model.VariableNames[i] : $"x{i + 1}";
                    rows.Add(new VariableRow { Name = name, Value = ResultLogger.Fmt(result.VariableValues[i]) });
                }
                VariablesGrid.ItemsSource = rows;
            }
            else
            {
                TxtObjectiveValue.Text = "—";
                VariablesGrid.ItemsSource = null;
            }
        }

        private void ResetResultSummary()
        {
            TxtStatus.Text = "NOT SOLVED";
            TxtStatus.Foreground = (Brush)FindResource("TextSecondaryBrush");
            StatusBadge.Background = (Brush)FindResource("BorderBrush2");
            TxtAlgorithmUsed.Text = "No algorithm run yet";
            TxtObjectiveValue.Text = "—";
            VariablesGrid.ItemsSource = null;
        }

        // =====================================================================
        // Sensitivity analysis
        // =====================================================================

        private void BuildSensitivityList()
        {
            var operations = new (string Name, string Description, Action Handler)[]
            {
                ("Shadow Prices", "Displays the dual value (shadow price) of every constraint.", Op_ShadowPrices),
                ("Duality", "Builds the dual model, solves it, and checks strong/weak duality.", Op_Duality),
                ("Range of a Non-Basic Variable", "How far a non-basic variable's objective coefficient can move before the basis changes.", Op_RangeNonBasic),
                ("Apply Change - Non-Basic Variable", "Set a new objective coefficient for a non-basic variable.", Op_ApplyNonBasic),
                ("Range of a Basic Variable", "How far a basic variable's objective coefficient can move before the basis changes.", Op_RangeBasic),
                ("Apply Change - Basic Variable", "Set a new objective coefficient for a basic variable.", Op_ApplyBasic),
                ("Range of a Constraint RHS", "How far a constraint's right-hand-side can move while the basis stays feasible.", Op_RangeRhs),
                ("Apply Change - Constraint RHS", "Set a new right-hand-side value for a constraint.", Op_ApplyRhs),
                ("Range of a Non-Basic Column Variable", "How far one technological coefficient inside a non-basic variable's column can move.", Op_RangeNonBasicColumn),
                ("Apply Change - Non-Basic Column Variable", "Set a new technological coefficient inside a non-basic variable's column.", Op_ApplyNonBasicColumn),
                ("Add a New Activity", "Add a brand-new decision variable to the model and re-solve.", Op_AddActivity),
                ("Add a New Constraint", "Add a brand-new constraint to the model and re-solve if needed.", Op_AddConstraint),
            };

            SensitivityList.Children.Clear();
            foreach (var op in operations)
            {
                var button = new Button { Style = (Style)FindResource("OptionCardButton") };
                var stack = new StackPanel();
                stack.Children.Add(new TextBlock { Text = op.Name, FontWeight = FontWeights.SemiBold, FontSize = 14 });
                stack.Children.Add(new TextBlock { Text = op.Description, Style = (Style)FindResource("BodyText"), Margin = new Thickness(0, 4, 0, 0) });
                button.Content = stack;
                button.Click += (_, _) => op.Handler();
                SensitivityList.Children.Add(button);
            }
        }

        /// <summary>Guard used by every sensitivity operation: makes sure there is a model and an optimal solve to act on.</summary>
        private bool RequireOptimalSolve()
        {
            if (_model is null || _lastResult is null || _lastResult.Status != SolutionStatus.Optimal)
            {
                MessageBox.Show(this, "Solve the model to optimality first (see the Solve tab).", "No optimal solution available",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            return true;
        }

        /// <summary>Runs a sensitivity action, streaming its log into the live log panel and the output file.</summary>
        private void RunSensitivityAction(Action<ResultLogger> action)
        {
            NavSensitivity.IsChecked = true;
            LogBox.Clear();
            var log = new ResultLogger(echoToConsole: false);
            log.LineWritten += line => AppendLog(line);

            try
            {
                action(log);
            }
            catch (Exception ex)
            {
                AppendLog($"[ERROR] {ex.Message}");
            }

            try { log.FlushToFile(_outputPath, append: true); }
            catch (IOException ex) { AppendLog($"[ERROR] Could not write to output file: {ex.Message}"); }
        }

        private static double[]? ParseNumberList(string text, int expectedCount)
        {
            var parts = text.Split(new[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length != expectedCount) return null;
            var parsed = new double[expectedCount];
            for (int i = 0; i < expectedCount; i++)
                if (!double.TryParse(parts[i], out parsed[i])) return null;
            return parsed;
        }

        private void NotifyNothingToPick(string message) =>
            MessageBox.Show(this, message, "Nothing available", MessageBoxButton.OK, MessageBoxImage.Information);

        private void NotifyInvalidInput(string message) =>
            MessageBox.Show(this, message, "Invalid input", MessageBoxButton.OK, MessageBoxImage.Warning);

        // ---- 1/2: Shadow Prices, Duality (no extra input needed) ----

        private void Op_ShadowPrices()
        {
            if (!RequireOptimalSolve()) return;
            RunSensitivityAction(log => SensitivityAnalyzer.DisplayShadowPrices(_model!, _lastResult!, log));
        }

        private void Op_Duality()
        {
            if (!RequireOptimalSolve()) return;
            RunSensitivityAction(log => SensitivityAnalyzer.SolveDualAndCheckDuality(_model!, _lastResult!, log));
        }

        // ---- 3/4: Non-Basic Variable range / apply ----

        private void Op_RangeNonBasic()
        {
            if (!RequireOptimalSolve()) return;
            var indices = SensitivityAnalyzer.GetNonBasicVariableIndices(_model!, _lastResult!);
            if (indices.Count == 0) { NotifyNothingToPick("There are no non-basic variables to range (or all are unrestricted 'urs', which isn't supported)."); return; }

            var options = indices.Select(i => _model!.VariableNames[i]).ToList();
            var answer = PromptDialog.Show(this, "Range of a Non-Basic Variable",
                new List<PromptDialog.Field> { new() { Label = "Select a non-basic variable:", Options = options } });
            if (answer == null) return;

            int varIndex = indices[options.IndexOf(answer[0])];
            RunSensitivityAction(log => SensitivityAnalyzer.RangeNonBasicVariable(_model!, _lastResult!, varIndex, log));
        }

        private void Op_ApplyNonBasic()
        {
            if (!RequireOptimalSolve()) return;
            var indices = SensitivityAnalyzer.GetNonBasicVariableIndices(_model!, _lastResult!);
            if (indices.Count == 0) { NotifyNothingToPick("There are no non-basic variables to change (or all are unrestricted 'urs', which isn't supported)."); return; }

            var options = indices.Select(i => _model!.VariableNames[i]).ToList();
            var fields = new List<PromptDialog.Field>
            {
                new() { Label = "Select a non-basic variable:", Options = options },
                new() { Label = "New objective coefficient:", DefaultText = "0" }
            };
            var answer = PromptDialog.Show(this, "Apply Change - Non-Basic Variable", fields);
            if (answer == null) return;
            if (!double.TryParse(answer[1], out double newValue)) { NotifyInvalidInput("Please enter a valid number."); return; }

            int varIndex = indices[options.IndexOf(answer[0])];
            RunSensitivityAction(log =>
            {
                var newResult = SensitivityAnalyzer.ApplyNonBasicVariableChange(_model!, _lastResult!, varIndex, newValue, log);
                if (newResult != null) { _lastResult = newResult; UpdateResultSummary(newResult); }
            });
        }

        // ---- 5/6: Basic Variable range / apply ----

        private void Op_RangeBasic()
        {
            if (!RequireOptimalSolve()) return;
            var indices = SensitivityAnalyzer.GetBasicVariableIndices(_model!, _lastResult!);
            if (indices.Count == 0) { NotifyNothingToPick("There are no basic variables to range."); return; }

            var options = indices.Select(i => _model!.VariableNames[i]).ToList();
            var answer = PromptDialog.Show(this, "Range of a Basic Variable",
                new List<PromptDialog.Field> { new() { Label = "Select a basic variable:", Options = options } });
            if (answer == null) return;

            int varIndex = indices[options.IndexOf(answer[0])];
            RunSensitivityAction(log => SensitivityAnalyzer.RangeBasicVariable(_model!, _lastResult!, varIndex, log));
        }

        private void Op_ApplyBasic()
        {
            if (!RequireOptimalSolve()) return;
            var indices = SensitivityAnalyzer.GetBasicVariableIndices(_model!, _lastResult!);
            if (indices.Count == 0) { NotifyNothingToPick("There are no basic variables to change."); return; }

            var options = indices.Select(i => _model!.VariableNames[i]).ToList();
            var fields = new List<PromptDialog.Field>
            {
                new() { Label = "Select a basic variable:", Options = options },
                new() { Label = "New objective coefficient:", DefaultText = "0" }
            };
            var answer = PromptDialog.Show(this, "Apply Change - Basic Variable", fields);
            if (answer == null) return;
            if (!double.TryParse(answer[1], out double newValue)) { NotifyInvalidInput("Please enter a valid number."); return; }

            int varIndex = indices[options.IndexOf(answer[0])];
            RunSensitivityAction(log =>
            {
                var newResult = SensitivityAnalyzer.ApplyBasicVariableChange(_model!, _lastResult!, varIndex, newValue, log);
                if (newResult != null) { _lastResult = newResult; UpdateResultSummary(newResult); }
            });
        }

        // ---- 7/8: Constraint RHS range / apply ----

        private List<string> ConstraintOptionLabels() =>
            Enumerable.Range(0, _model!.Constraints.Count)
                .Select(i => $"Constraint {i + 1} ({_model!.Constraints[i].RelationSymbol} {ResultLogger.Fmt(_model!.Constraints[i].Rhs)})")
                .ToList();

        private void Op_RangeRhs()
        {
            if (!RequireOptimalSolve()) return;
            var options = ConstraintOptionLabels();
            var answer = PromptDialog.Show(this, "Range of a Constraint RHS",
                new List<PromptDialog.Field> { new() { Label = "Select a constraint:", Options = options } });
            if (answer == null) return;

            int constraintIndex = options.IndexOf(answer[0]);
            RunSensitivityAction(log => SensitivityAnalyzer.RangeConstraintRhs(_model!, _lastResult!, constraintIndex, log));
        }

        private void Op_ApplyRhs()
        {
            if (!RequireOptimalSolve()) return;
            var options = ConstraintOptionLabels();
            var fields = new List<PromptDialog.Field>
            {
                new() { Label = "Select a constraint:", Options = options },
                new() { Label = "New right-hand-side value:", DefaultText = "0" }
            };
            var answer = PromptDialog.Show(this, "Apply Change - Constraint RHS", fields);
            if (answer == null) return;
            if (!double.TryParse(answer[1], out double newRhs)) { NotifyInvalidInput("Please enter a valid number."); return; }

            int constraintIndex = options.IndexOf(answer[0]);
            RunSensitivityAction(log =>
            {
                var newResult = SensitivityAnalyzer.ApplyConstraintRhsChange(_model!, _lastResult!, constraintIndex, newRhs, log);
                if (newResult != null) { _lastResult = newResult; UpdateResultSummary(newResult); }
            });
        }

        // ---- 9/10: coefficient inside a Non-Basic column range / apply ----

        private void Op_RangeNonBasicColumn()
        {
            if (!RequireOptimalSolve()) return;
            var varIndices = SensitivityAnalyzer.GetNonBasicVariableIndices(_model!, _lastResult!);
            if (varIndices.Count == 0) { NotifyNothingToPick("There are no non-basic variables available (or all are unrestricted 'urs', which isn't supported)."); return; }

            var varOptions = varIndices.Select(i => _model!.VariableNames[i]).ToList();
            var constraintOptions = ConstraintOptionLabels();
            var fields = new List<PromptDialog.Field>
            {
                new() { Label = "Select a non-basic variable (the column):", Options = varOptions },
                new() { Label = "Select a constraint (the row):", Options = constraintOptions }
            };
            var answer = PromptDialog.Show(this, "Range of a Non-Basic Column Coefficient", fields);
            if (answer == null) return;

            int varIndex = varIndices[varOptions.IndexOf(answer[0])];
            int constraintIndex = constraintOptions.IndexOf(answer[1]);
            RunSensitivityAction(log => SensitivityAnalyzer.RangeNonBasicColumnCoefficient(_model!, _lastResult!, varIndex, constraintIndex, log));
        }

        private void Op_ApplyNonBasicColumn()
        {
            if (!RequireOptimalSolve()) return;
            var varIndices = SensitivityAnalyzer.GetNonBasicVariableIndices(_model!, _lastResult!);
            if (varIndices.Count == 0) { NotifyNothingToPick("There are no non-basic variables available (or all are unrestricted 'urs', which isn't supported)."); return; }

            var varOptions = varIndices.Select(i => _model!.VariableNames[i]).ToList();
            var constraintOptions = ConstraintOptionLabels();
            var fields = new List<PromptDialog.Field>
            {
                new() { Label = "Select a non-basic variable (the column):", Options = varOptions },
                new() { Label = "Select a constraint (the row):", Options = constraintOptions },
                new() { Label = "New coefficient value:", DefaultText = "0" }
            };
            var answer = PromptDialog.Show(this, "Apply Change - Non-Basic Column Coefficient", fields);
            if (answer == null) return;
            if (!double.TryParse(answer[2], out double newValue)) { NotifyInvalidInput("Please enter a valid number."); return; }

            int varIndex = varIndices[varOptions.IndexOf(answer[0])];
            int constraintIndex = constraintOptions.IndexOf(answer[1]);
            RunSensitivityAction(log =>
            {
                var newResult = SensitivityAnalyzer.ApplyNonBasicColumnCoefficientChange(_model!, _lastResult!, varIndex, constraintIndex, newValue, log);
                if (newResult != null) { _lastResult = newResult; UpdateResultSummary(newResult); }
            });
        }

        // ---- 11: Add a new activity ----

        private void Op_AddActivity()
        {
            if (!RequireOptimalSolve()) return;
            var fields = new List<PromptDialog.Field>
            {
                new() { Label = "Objective coefficient of the new activity:", DefaultText = "0" },
                new() { Label = $"Constraint coefficients, one per existing constraint (comma or space separated, {_model!.Constraints.Count} values):", DefaultText = string.Join(" ", Enumerable.Repeat("0", _model!.Constraints.Count)) },
                new() { Label = "Sign restriction:", Options = new List<string> { "Positive (+)", "Integer (int)", "Binary (bin)" } }
            };
            var answer = PromptDialog.Show(this, "Add a New Activity", fields);
            if (answer == null) return;

            if (!double.TryParse(answer[0], out double objectiveCoefficient)) { NotifyInvalidInput("Please enter a valid objective coefficient."); return; }
            var coefficients = ParseNumberList(answer[1], _model!.Constraints.Count);
            if (coefficients == null) { NotifyInvalidInput($"Please enter exactly {_model!.Constraints.Count} numeric coefficients."); return; }

            var restriction = answer[2] switch
            {
                "Integer (int)" => VariableRestriction.Integer,
                "Binary (bin)" => VariableRestriction.Binary,
                _ => VariableRestriction.Positive
            };

            RunSensitivityAction(log =>
            {
                var newResult = SensitivityAnalyzer.AddNewActivity(_model!, _lastResult!, objectiveCoefficient, coefficients, restriction, log);
                _lastResult = newResult;
                UpdateResultSummary(newResult);
            });
        }

        // ---- 12: Add a new constraint ----

        private void Op_AddConstraint()
        {
            if (!RequireOptimalSolve()) return;
            var fields = new List<PromptDialog.Field>
            {
                new() { Label = $"Coefficients, one per variable (comma or space separated, {_model!.VariableCount} values):", DefaultText = string.Join(" ", Enumerable.Repeat("0", _model!.VariableCount)) },
                new() { Label = "Relation:", Options = new List<string> { "<=", ">=", "=" } },
                new() { Label = "Right-hand-side:", DefaultText = "0" }
            };
            var answer = PromptDialog.Show(this, "Add a New Constraint", fields);
            if (answer == null) return;

            var coefficients = ParseNumberList(answer[0], _model!.VariableCount);
            if (coefficients == null) { NotifyInvalidInput($"Please enter exactly {_model!.VariableCount} numeric coefficients."); return; }
            if (!double.TryParse(answer[2], out double rhs)) { NotifyInvalidInput("Please enter a valid right-hand-side value."); return; }

            var relation = answer[1] switch
            {
                ">=" => RelationType.GreaterOrEqual,
                "=" => RelationType.Equal,
                _ => RelationType.LessOrEqual
            };

            RunSensitivityAction(log =>
            {
                var newResult = SensitivityAnalyzer.AddNewConstraint(_model!, _lastResult!, coefficients, relation, rhs, log);
                _lastResult = newResult;
                UpdateResultSummary(newResult);
            });
        }

        // =====================================================================
        // Settings
        // =====================================================================

        private void BrowseOutput_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new SaveFileDialog { Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*", FileName = _outputPath };
            if (dialog.ShowDialog() == true)
                TxtOutputPath.Text = dialog.FileName;
        }

        private void SaveOutputPath_Click(object sender, RoutedEventArgs e)
        {
            string path = TxtOutputPath.Text.Trim();
            if (string.IsNullOrWhiteSpace(path))
            {
                SettingsStatusBanner.Visibility = Visibility.Visible;
                SettingsStatusBanner.Background = (Brush)FindResource("ErrorBgBrush");
                TxtSettingsStatus.Foreground = (Brush)FindResource("ErrorBrush");
                TxtSettingsStatus.Text = "Please enter a valid output file path.";
                return;
            }

            _outputPath = path;
            TxtOutputFileHint.Text = _outputPath;

            SettingsStatusBanner.Visibility = Visibility.Visible;
            SettingsStatusBanner.Background = (Brush)FindResource("SuccessBgBrush");
            TxtSettingsStatus.Foreground = (Brush)FindResource("SuccessBrush");
            TxtSettingsStatus.Text = $"Output file path set to '{_outputPath}'.";
        }

        private void ClearLog_Click(object sender, RoutedEventArgs e) => LogBox.Clear();
    }
}
