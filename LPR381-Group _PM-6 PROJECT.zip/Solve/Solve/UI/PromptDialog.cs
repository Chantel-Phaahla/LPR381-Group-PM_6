using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace Solve.UI
{
    /// <summary>
    /// A small, generic, code-only (no separate .xaml file) modal dialog used to
    /// gather the extra parameters sensitivity-analysis operations need (which
    /// variable/constraint to act on, and/or a new numeric value). Built entirely
    /// in C# to avoid adding more XAML surface area.
    /// </summary>
    public static class PromptDialog
    {
        /// <summary>One input row: either a dropdown (when <see cref="Options"/> is set) or a free-text box.</summary>
        public class Field
        {
            public string Label = string.Empty;
            public List<string>? Options;   // non-null => renders as a ComboBox
            public string DefaultText = string.Empty; // used when Options is null
        }

        /// <summary>
        /// Shows the dialog. Returns the entered values (one string per field, in
        /// the same order as <paramref name="fields"/>) if the user clicked OK, or
        /// null if they cancelled or closed the window.
        /// </summary>
        public static List<string>? Show(Window owner, string title, List<Field> fields)
        {
            var window = new Window
            {
                Title = title,
                Width = 440,
                SizeToContent = SizeToContent.Height,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = owner,
                ResizeMode = ResizeMode.NoResize,
                ShowInTaskbar = false
            };

            var rootPanel = new StackPanel { Margin = new Thickness(18) };
            var inputControls = new List<Control>();

            foreach (var field in fields)
            {
                rootPanel.Children.Add(new TextBlock
                {
                    Text = field.Label,
                    Margin = new Thickness(0, 10, 0, 4),
                    FontWeight = FontWeights.SemiBold
                });

                if (field.Options != null)
                {
                    var combo = new ComboBox
                    {
                        ItemsSource = field.Options,
                        SelectedIndex = field.Options.Count > 0 ? 0 : -1,
                        Padding = new Thickness(6)
                    };
                    rootPanel.Children.Add(combo);
                    inputControls.Add(combo);
                }
                else
                {
                    var textBox = new TextBox
                    {
                        Text = field.DefaultText,
                        Padding = new Thickness(6)
                    };
                    rootPanel.Children.Add(textBox);
                    inputControls.Add(textBox);
                }
            }

            bool accepted = false;

            var buttonRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0, 18, 0, 0)
            };
            var okButton = new Button { Content = "OK", Width = 84, Margin = new Thickness(0, 0, 8, 0), IsDefault = true, Padding = new Thickness(6) };
            var cancelButton = new Button { Content = "Cancel", Width = 84, IsCancel = true, Padding = new Thickness(6) };
            okButton.Click += (_, _) => { accepted = true; window.Close(); };
            cancelButton.Click += (_, _) => { accepted = false; window.Close(); };
            buttonRow.Children.Add(okButton);
            buttonRow.Children.Add(cancelButton);
            rootPanel.Children.Add(buttonRow);

            window.Content = rootPanel;
            window.ShowDialog();

            if (!accepted) return null;

            var results = new List<string>();
            foreach (var control in inputControls)
            {
                if (control is ComboBox comboBox) results.Add(comboBox.SelectedItem as string ?? string.Empty);
                else if (control is TextBox textBox) results.Add(textBox.Text);
                else results.Add(string.Empty);
            }
            return results;
        }
    }
}
