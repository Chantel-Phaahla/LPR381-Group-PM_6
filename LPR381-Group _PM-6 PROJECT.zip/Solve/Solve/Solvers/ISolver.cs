using Solve.IO;
using Solve.Models;

namespace Solve.Solvers
{
    /// <summary>
    /// Contract implemented by every algorithm in the "Algorithms to be available"
    /// list (Primal Simplex, Revised Primal Simplex, Branch &amp; Bound Simplex,
    /// Cutting Plane, Knapsack Branch &amp; Bound...). The menu layer is written
    /// entirely against this interface, so a new algorithm can be dropped in
    /// without touching Program.cs or the I/O layer.
    /// </summary>
    public interface ISolver
    {
        /// <summary>Display name shown in the menu and written to the output file.</summary>
        string Name { get; }

        /// <summary>
        /// Solves the given model, streaming the canonical form and every
        /// iteration/tableau through <paramref name="log"/> as it goes.
        /// </summary>
        SolveResult Solve(LPModel model, ResultLogger log);
    }
}
