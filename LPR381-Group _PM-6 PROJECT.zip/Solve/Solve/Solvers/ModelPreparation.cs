using System.Collections.Generic;
using Solve.Models;

namespace Solve.Solvers
{
    /// <summary>
    /// Small shared helper used by every algorithm that first needs an LP
    /// relaxation of the model (Cutting Plane, Branch &amp; Bound, ...).
    /// </summary>
    public static class ModelPreparation
    {
        /// <summary>
        /// Returns a clone of <paramref name="model"/> where every 'bin' variable has
        /// an explicit "x &lt;= 1" constraint appended (its "x &gt;= 0" lower bound is
        /// already implied by the Positive-family handling in <see cref="SimplexTableau"/>).
        /// This turns the model into a plain LP relaxation that the simplex engine can solve directly.
        /// </summary>
        public static LPModel BuildLpRelaxation(LPModel model)
        {
            var clone = model.Clone();

            for (int i = 0; i < clone.VariableCount; i++)
            {
                if (clone.SignRestrictions[i] == VariableRestriction.Binary)
                {
                    var coeffs = new List<double>(new double[clone.VariableCount]);
                    coeffs[i] = 1.0;
                    clone.Constraints.Add(new Constraint(coeffs, RelationType.LessOrEqual, 1.0));
                    // Treat as a plain non-negative continuous variable for the relaxation;
                    // integrality/binariness is re-imposed by the Cutting Plane / B&B wrapper.
                    clone.SignRestrictions[i] = VariableRestriction.Integer;
                }
            }

            return clone;
        }
    }
}
