using System;
using System.Collections.Generic;
using System.Linq;
using Solve.IO;
using Solve.Models;

namespace Solve.Solvers
{
    /// <summary>How an original decision variable maps onto the columns of the standard-form tableau.</summary>
    public enum MappingKind { Direct, Negated, Split }

    /// <summary>
    /// Describes how to recover the value of one ORIGINAL decision variable
    /// (as typed in the input file) from the columns of the standard-form
    /// tableau built for the simplex engine. This indirection is what lets the
    /// engine support "+", "-" and "urs" sign restrictions transparently.
    /// </summary>
    public class VariableMapping
    {
        public MappingKind Kind;
        public int ColumnIndex;     // used for Direct / Negated
        public int PositiveColumn;  // used for Split (x = x+ - x-)
        public int NegativeColumn;  // used for Split

        public double Recover(double[] columnValues) => Kind switch
        {
            MappingKind.Direct => columnValues[ColumnIndex],
            MappingKind.Negated => -columnValues[ColumnIndex],
            MappingKind.Split => columnValues[PositiveColumn] - columnValues[NegativeColumn],
            _ => 0
        };
    }

    /// <summary>
    /// Mutable state of a Big-M Primal Simplex tableau: the numeric matrix,
    /// column headings, and which column is basic in every row. Both the
    /// Primal Simplex solver and the Cutting Plane solver operate on this
    /// object, so a Gomory cut can simply be appended as a brand-new row.
    /// </summary>
    public class SimplexTableau
    {
        public double[,] Data = null!;               // (m+1) rows x (totalCols+1) columns, row 0 = objective row
        public List<string> ColumnNames = null!;      // length = totalCols (excludes RHS)
        public List<int> BasicColumnOfRow = null!;    // length = m, BasicColumnOfRow[i] = column index basic in row i+1
        public List<bool> IsArtificial = null!;
        public List<VariableMapping> VariableMappings = null!; // one per ORIGINAL decision variable
        public bool OriginalIsMinimization;
        public const double BigM = 1_000_000d;
        public const double Epsilon = 1e-9;

        /// <summary>
        /// A frozen COPY of BasicColumnOfRow taken the instant the tableau was built
        /// (before any pivoting). Row r's entry is always the column that started as
        /// the pure identity vector e_r for that row (the slack for a '&lt;=' row, or
        /// the artificial for a '&gt;=' / '=' row) - this is exactly what sensitivity
        /// analysis needs to read B^-1 back out of the finished tableau: that column's
        /// FINAL values equal B^-1 * e_r, i.e. B^-1's r-th column.
        /// </summary>
        public List<int> InitialBasicColumnOfRow = null!;

        /// <summary>
        /// +1 if row r's constraint was used as-is, or -1 if it was multiplied through
        /// by -1 during RHS normalisation (only happens when the original RHS was
        /// negative). Needed so B^-1 columns / shadow prices read off the tableau can be
        /// converted back to be "with respect to the user's ORIGINAL right-hand-side",
        /// rather than the internally-normalised one.
        /// </summary>
        public double[] RowSign = null!;

        public int Rows => Data.GetLength(0);      // m + 1
        public int Cols => Data.GetLength(1);      // totalCols + 1 (RHS is last)
        public int RhsIndex => Cols - 1;

        /// <summary>Number of original constraints (rows) this tableau was built from.</summary>
        public int ConstraintCount => InitialBasicColumnOfRow.Count;

        /// <summary>
        /// Reads B^-1's column for constraint <paramref name="constraintIndex"/> (0-based)
        /// directly off the current tableau, already corrected for any RHS-sign
        /// normalisation so it is expressed with respect to the ORIGINAL right-hand-side
        /// the user entered. d(basic variable values)/d(RHS of that constraint) = this column.
        /// Covers every CURRENT row (including any Gomory cut rows appended after the
        /// original constraints), since perturbing an original RHS also moves those rows.
        /// </summary>
        public double[] GetBasisInverseColumnByRow(int constraintIndex)
        {
            int col = InitialBasicColumnOfRow[constraintIndex];
            int currentRowCount = Rows - 1;
            var result = new double[currentRowCount];
            for (int r = 0; r < currentRowCount; r++)
                result[r] = Data[r + 1, col] * RowSign[constraintIndex];
            return result;
        }

        /// <summary>
        /// The shadow price (dual value) of constraint <paramref name="constraintIndex"/>,
        /// in the INTERNAL maximisation sense (i.e. NOT yet flipped for an original
        /// minimisation problem) and already corrected for RHS-sign normalisation. This
        /// is d(internal objective)/d(original RHS of that constraint).
        /// </summary>
        public double GetShadowPriceInternal(int constraintIndex)
        {
            int col = InitialBasicColumnOfRow[constraintIndex];
            double y = IsArtificial[col] ? Data[0, col] - BigM : Data[0, col];
            return y * RowSign[constraintIndex];
        }

        /// <summary>Current reduced cost (row-0 value) of a column, in the internal maximisation sense.</summary>
        public double ReducedCost(int col) => Data[0, col];

        /// <summary>
        /// Snapshot of every original decision variable's current tableau column value
        /// (0 for non-basic), used by sensitivity operations that need to rebuild a
        /// perturbed solution without re-solving from scratch.
        /// </summary>
        public double[] GetColumnValues()
        {
            var columnValues = new double[ColumnNames.Count];
            for (int r = 0; r < BasicColumnOfRow.Count; r++)
                columnValues[BasicColumnOfRow[r]] = Data[r + 1, RhsIndex];
            return columnValues;
        }

        /// <summary>Maps a full column-values snapshot back to the original decision variables.</summary>
        public double[] RecoverVariableValues(double[] columnValues)
        {
            var values = new double[VariableMappings.Count];
            for (int i = 0; i < VariableMappings.Count; i++)
                values[i] = ResultLogger.Round3(VariableMappings[i].Recover(columnValues));
            return values;
        }

        /// <summary>Converts an internal-sense (always-maximised) objective value back to the model's original sense.</summary>
        public double ToOriginalObjective(double internalValue) => OriginalIsMinimization ? -internalValue : internalValue;

        /// <summary>
        /// Builds the initial Big-M standard-form tableau for the supplied model.
        /// The model is converted to an equivalent MAXIMISATION problem internally;
        /// results are converted back to the original sense when reported.
        /// </summary>
        public static SimplexTableau Build(LPModel model)
        {
            var tableau = new SimplexTableau
            {
                OriginalIsMinimization = model.Sense == ObjectiveSense.Minimize
            };

            // Internal objective coefficients, always expressed as a MAXIMISATION problem.
            double sign = tableau.OriginalIsMinimization ? -1.0 : 1.0;

            // ---- Step 1: decide how each original variable maps to tableau column(s) ----
            var mappings = new List<VariableMapping>();
            var colNames = new List<string>();
            var colCosts = new List<double>();
            // Per-original-variable expansion of "the coefficient in this column, given a
            // 1.0 coefficient on the original variable", used later while writing constraint rows.
            var expansions = new List<(int col, double factor)[]>();

            for (int i = 0; i < model.VariableCount; i++)
            {
                var restriction = model.SignRestrictions[i];
                double objCoef = sign * model.ObjectiveCoefficients[i];
                string baseName = model.VariableNames[i];

                if (restriction == VariableRestriction.Negative)
                {
                    // x <= 0  =>  substitute x = -y, y >= 0
                    int col = colNames.Count;
                    colNames.Add(baseName);
                    colCosts.Add(-objCoef);
                    mappings.Add(new VariableMapping { Kind = MappingKind.Negated, ColumnIndex = col });
                    expansions.Add(new[] { (col, -1.0) });
                }
                else if (restriction == VariableRestriction.Unrestricted)
                {
                    // x free  =>  substitute x = x+ - x-, both >= 0
                    int posCol = colNames.Count;
                    colNames.Add(baseName + "+");
                    colCosts.Add(objCoef);
                    int negCol = colNames.Count;
                    colNames.Add(baseName + "-");
                    colCosts.Add(-objCoef);
                    mappings.Add(new VariableMapping { Kind = MappingKind.Split, PositiveColumn = posCol, NegativeColumn = negCol });
                    expansions.Add(new[] { (posCol, 1.0), (negCol, -1.0) });
                }
                else
                {
                    // Positive, Integer, Binary all behave as ordinary x >= 0 at the LP-relaxation level.
                    // (Integrality/binariness is enforced by the caller: Cutting Plane / Branch & Bound.)
                    int col = colNames.Count;
                    colNames.Add(baseName);
                    colCosts.Add(objCoef);
                    mappings.Add(new VariableMapping { Kind = MappingKind.Direct, ColumnIndex = col });
                    expansions.Add(new[] { (col, 1.0) });
                }
            }

            int decisionCols = colNames.Count;
            int m = model.Constraints.Count;

            // ---- Step 2: normalise each constraint so its RHS is non-negative -------
            // (needed so a starting slack/artificial basis of "= RHS" is itself feasible-looking).
            // A row is normalised BEFORE slack/artificial columns are chosen, because
            // multiplying a "<=" row through by -1 turns it into a ">=" row (and vice
            // versa) - the wrong choice here would corrupt the identity-column structure
            // the simplex method relies on for its initial basis.
            var normalisedRows = new double[m][];
            var normalisedRhs = new double[m];
            var normalisedRelation = new RelationType[m];
            var rowSign = new double[m];

            for (int r = 0; r < m; r++)
            {
                var c = model.Constraints[r];
                var row = new double[decisionCols];
                for (int i = 0; i < model.VariableCount; i++)
                    foreach (var (col, factor) in expansions[i])
                        row[col] += factor * c.Coefficients[i];

                double rhs = c.Rhs;
                var relation = c.Relation;
                double rowSignValue = 1.0;

                if (rhs < 0)
                {
                    for (int j = 0; j < decisionCols; j++) row[j] = -row[j];
                    rhs = -rhs;
                    rowSignValue = -1.0;
                    relation = relation switch
                    {
                        RelationType.LessOrEqual => RelationType.GreaterOrEqual,
                        RelationType.GreaterOrEqual => RelationType.LessOrEqual,
                        _ => RelationType.Equal
                    };
                }

                normalisedRows[r] = row;
                normalisedRhs[r] = rhs;
                normalisedRelation[r] = relation;
                rowSign[r] = rowSignValue;
            }

            // ---- Step 3: add slack / surplus / artificial columns, based on the NORMALISED relation ----
            var basicColumnOfRow = new List<int>();
            var isArtificial = new List<bool>();
            for (int i = 0; i < decisionCols; i++) isArtificial.Add(false);

            var rowExtra = new List<(int slackCol, double slackCoef, int artCol)>();

            for (int r = 0; r < m; r++)
            {
                int slackCol = -1, artCol = -1;
                double slackCoef = 0;

                if (normalisedRelation[r] == RelationType.LessOrEqual)
                {
                    slackCol = colNames.Count;
                    colNames.Add($"s{r + 1}");
                    colCosts.Add(0);
                    isArtificial.Add(false);
                    slackCoef = 1.0;
                    basicColumnOfRow.Add(slackCol);
                }
                else if (normalisedRelation[r] == RelationType.GreaterOrEqual)
                {
                    slackCol = colNames.Count;
                    colNames.Add($"s{r + 1}");
                    colCosts.Add(0);
                    isArtificial.Add(false);
                    slackCoef = -1.0;

                    artCol = colNames.Count;
                    colNames.Add($"a{r + 1}");
                    colCosts.Add(-BigM);
                    isArtificial.Add(true);
                    basicColumnOfRow.Add(artCol);
                }
                else // Equal
                {
                    artCol = colNames.Count;
                    colNames.Add($"a{r + 1}");
                    colCosts.Add(-BigM);
                    isArtificial.Add(true);
                    basicColumnOfRow.Add(artCol);
                }

                rowExtra.Add((slackCol, slackCoef, artCol));
            }

            int totalCols = colNames.Count;
            var data = new double[m + 1, totalCols + 1];

            // ---- Step 4: fill in constraint rows from the normalised data ----
            for (int r = 0; r < m; r++)
            {
                for (int j = 0; j < decisionCols; j++)
                    data[r + 1, j] = normalisedRows[r][j];

                var (slackCol, slackCoef, artCol) = rowExtra[r];
                if (slackCol >= 0) data[r + 1, slackCol] = slackCoef;
                if (artCol >= 0) data[r + 1, artCol] = 1.0;

                data[r + 1, totalCols] = normalisedRhs[r];
            }

            // ---- Step 4: objective row (row 0), then eliminate basic artificials ----
            for (int j = 0; j < totalCols; j++)
                data[0, j] = -colCosts[j];
            data[0, totalCols] = 0;

            for (int r = 0; r < m; r++)
            {
                int basicCol = basicColumnOfRow[r];
                if (isArtificial[basicCol])
                {
                    double factor = data[0, basicCol]; // = M at this point
                    for (int j = 0; j <= totalCols; j++)
                        data[0, j] -= factor * data[r + 1, j];
                }
            }

            tableau.Data = data;
            tableau.ColumnNames = colNames;
            tableau.BasicColumnOfRow = basicColumnOfRow;
            tableau.IsArtificial = isArtificial;
            tableau.VariableMappings = mappings;
            tableau.InitialBasicColumnOfRow = new List<int>(basicColumnOfRow); // frozen copy - basicColumnOfRow itself mutates as Pivot() runs
            tableau.RowSign = rowSign;
            return tableau;
        }

        /// <summary>Prints the current tableau (canonical form / an iteration) through the logger.</summary>
        public void Print(ResultLogger log, string caption)
        {
            log.WriteSubHeading(caption);
            var headers = ColumnNames.Append("RHS").ToArray();
            var rowLabels = new List<string> { "z" };
            for (int r = 0; r < BasicColumnOfRow.Count; r++)
                rowLabels.Add(ColumnNames[BasicColumnOfRow[r]]);
            log.WriteTable(headers, rowLabels, Data);
        }

        /// <summary>
        /// Runs the Big-M Primal Simplex method to optimality on this tableau,
        /// logging every pivot as a full tableau iteration. Uses Bland's Rule
        /// (smallest index) for both entering-variable and leaving-variable
        /// selection, which guarantees the method terminates (no cycling).
        /// </summary>
        public SolveResult RunPrimalSimplex(ResultLogger log, string algorithmName, LPModel originalModel)
        {
            Print(log, "Canonical Form / Initial Tableau");

            int iteration = 0;
            const int maxIterations = 2000;

            while (true)
            {
                // Find entering column: smallest-index column with a negative row-0 value (Bland's rule).
                int enter = -1;
                for (int j = 0; j < Cols - 1; j++)
                {
                    if (Data[0, j] < -Epsilon) { enter = j; break; }
                }

                if (enter == -1)
                    break; // optimal

                // Ratio test: smallest index among ties (Bland's rule) to avoid cycling.
                int leaveRow = -1;
                double bestRatio = double.PositiveInfinity;
                for (int r = 1; r < Rows; r++)
                {
                    double coef = Data[r, enter];
                    if (coef > Epsilon)
                    {
                        double ratio = Data[r, RhsIndex] / coef;
                        if (ratio < bestRatio - Epsilon ||
                            (Math.Abs(ratio - bestRatio) <= Epsilon &&
                             (leaveRow == -1 || BasicColumnOfRow[r - 1] < BasicColumnOfRow[leaveRow - 1])))
                        {
                            bestRatio = ratio;
                            leaveRow = r;
                        }
                    }
                }

                if (leaveRow == -1)
                {
                    return SolveResult.Unbounded(algorithmName,
                        $"Column '{ColumnNames[enter]}' can increase without limit: the feasible region is unbounded.");
                }

                Pivot(leaveRow, enter);
                iteration++;
                Print(log, $"Iteration {iteration}: entering = {ColumnNames[enter]}, leaving = {ColumnNames[BasicColumnOfRow[leaveRow - 1]]}");

                if (iteration > maxIterations)
                {
                    log.WriteLine("Iteration limit reached - aborting to avoid a possible infinite loop.");
                    break;
                }
            }

            // Feasibility check: any artificial variable left basic with a positive value means infeasible.
            for (int r = 0; r < BasicColumnOfRow.Count; r++)
            {
                int basicCol = BasicColumnOfRow[r];
                if (IsArtificial[basicCol] && Data[r + 1, RhsIndex] > 1e-6)
                {
                    return SolveResult.Infeasible(algorithmName,
                        "An artificial variable remains in the basis at a positive value: no feasible solution exists.");
                }
            }

            return ExtractResult(algorithmName, originalModel);
        }

        /// <summary>Standard Gauss-Jordan pivot on (row, col).</summary>
        public void Pivot(int row, int col)
        {
            double pivotVal = Data[row, col];
            for (int j = 0; j < Cols; j++) Data[row, j] /= pivotVal;

            for (int r = 0; r < Rows; r++)
            {
                if (r == row) continue;
                double factor = Data[r, col];
                if (Math.Abs(factor) < Epsilon) continue;
                for (int j = 0; j < Cols; j++)
                    Data[r, j] -= factor * Data[row, j];
            }

            BasicColumnOfRow[row - 1] = col;
        }

        /// <summary>Reads off the current basic feasible solution and maps it back to the original variables.</summary>
        public SolveResult ExtractResult(string algorithmName, LPModel originalModel)
        {
            var columnValues = new double[ColumnNames.Count];
            for (int r = 0; r < BasicColumnOfRow.Count; r++)
                columnValues[BasicColumnOfRow[r]] = Data[r + 1, RhsIndex];

            var values = new double[VariableMappings.Count];
            for (int i = 0; i < VariableMappings.Count; i++)
                values[i] = ResultLogger.Round3(VariableMappings[i].Recover(columnValues));

            double objectiveInternal = Data[0, RhsIndex];
            double objective = OriginalIsMinimization ? -objectiveInternal : objectiveInternal;

            return new SolveResult
            {
                Status = SolutionStatus.Optimal,
                VariableValues = values,
                ObjectiveValue = ResultLogger.Round3(objective),
                AlgorithmName = algorithmName,
                Message = "Optimal solution found.",
                FinalTableau = this
            };
        }

        /// <summary>Current value of a given column (0 if non-basic).</summary>
        public double ColumnValue(int col)
        {
            for (int r = 0; r < BasicColumnOfRow.Count; r++)
                if (BasicColumnOfRow[r] == col) return Data[r + 1, RhsIndex];
            return 0.0;
        }

        /// <summary>Returns the 1-based tableau row in which the given column is currently basic, or -1.</summary>
        public int BasicRowOfColumn(int col)
        {
            for (int r = 0; r < BasicColumnOfRow.Count; r++)
                if (BasicColumnOfRow[r] == col) return r + 1;
            return -1;
        }

        private static double FracPart(double v)
        {
            double f = v - Math.Floor(v);
            // Snap numerical noise right at the boundaries back to a clean 0/1.
            if (f < 1e-7) return 0.0;
            if (f > 1 - 1e-7) return 0.0;
            return f;
        }

        /// <summary>
        /// Appends a Gomory fractional cut derived from <paramref name="sourceRow"/>
        /// (a 1-based row index whose basic variable currently has a fractional value)
        /// as a brand-new row and slack column of the tableau. The new row is primal
        /// infeasible (negative RHS) by construction; call
        /// <see cref="RunDualSimplexToFeasibility"/> immediately afterwards.
        /// </summary>
        public int AddGomoryCut(int sourceRow, int cutNumber)
        {
            int oldVarCols = RhsIndex;      // number of columns before RHS
            int newVarCols = oldVarCols + 1; // + new slack column for the cut
            int newRows = Rows + 1;
            int newTotalCols = newVarCols + 1; // + RHS

            var newData = new double[newRows, newTotalCols];

            for (int r = 0; r < Rows; r++)
            {
                for (int c = 0; c < oldVarCols; c++)
                    newData[r, c] = Data[r, c];
                newData[r, oldVarCols] = 0.0;              // new slack column
                newData[r, newVarCols] = Data[r, RhsIndex]; // RHS shifts one column right
            }

            int cutRow = Rows; // index of the brand-new row
            double rhsFrac = FracPart(Data[sourceRow, RhsIndex]);
            for (int c = 0; c < oldVarCols; c++)
            {
                double f = FracPart(Data[sourceRow, c]);
                newData[cutRow, c] = -f;
            }
            newData[cutRow, oldVarCols] = 1.0;   // the cut's own slack variable
            newData[cutRow, newVarCols] = -rhsFrac;

            Data = newData;
            ColumnNames.Add($"e{cutNumber}");
            IsArtificial.Add(false);
            BasicColumnOfRow.Add(oldVarCols);

            return cutRow;
        }

        /// <summary>
        /// Restores primal feasibility after a cut has been added, using the Dual
        /// Simplex Algorithm (the tableau remains dual-feasible/optimal throughout,
        /// since only rows - never the objective row - are modified by a cut).
        /// Returns false if the model is discovered to be infeasible.
        /// </summary>
        public bool RunDualSimplexToFeasibility(ResultLogger log)
        {
            int iteration = 0;
            while (true)
            {
                int leaveRow = -1;
                double mostNegative = -Epsilon;
                for (int r = 1; r < Rows; r++)
                {
                    if (Data[r, RhsIndex] < mostNegative)
                    {
                        mostNegative = Data[r, RhsIndex];
                        leaveRow = r;
                    }
                }

                if (leaveRow == -1) return true; // primal-feasible again

                int enterCol = -1;
                double bestRatio = double.PositiveInfinity;
                for (int j = 0; j < RhsIndex; j++)
                {
                    double coef = Data[leaveRow, j];
                    if (coef < -Epsilon)
                    {
                        double ratio = Data[0, j] / (-coef);
                        if (ratio < bestRatio - Epsilon ||
                            (Math.Abs(ratio - bestRatio) <= Epsilon && (enterCol == -1 || j < enterCol)))
                        {
                            bestRatio = ratio;
                            enterCol = j;
                        }
                    }
                }

                if (enterCol == -1) return false; // infeasible: no coefficient can bring the RHS back up

                string leavingName = ColumnNames[BasicColumnOfRow[leaveRow - 1]];
                Pivot(leaveRow, enterCol);
                iteration++;
                Print(log, $"Dual Simplex iteration {iteration}: leaving = {leavingName}, entering = {ColumnNames[enterCol]}");

                if (iteration > 500)
                {
                    log.WriteLine("Dual simplex iteration limit reached - aborting to avoid a possible infinite loop.");
                    return false;
                }
            }
        }
    }
}
