using System;
using System.Collections.Generic;
using System.Linq;
using Solve.IO;
using Solve.Models;

namespace Solve.Solvers
{
    /// <summary>
    /// Solves a Linear Programming model with the Revised Primal Simplex
    /// Algorithm: instead of updating a full (m+1) x (n+1) tableau every
    /// iteration (as <see cref="PrimalSimplexSolver"/> does), this keeps only
    /// the current basis inverse B^-1 and "prices out" each candidate column
    /// through it on demand. Every iteration logs:
    ///   - the Price-Out step: the simplex multipliers y = c_B^T B^-1 and the
    ///     resulting reduced cost of every non-basic column, and
    ///   - the Product Form step: the updated B^-1 (obtained via a single
    ///     eta/elimination update rather than recomputing a matrix inverse
    ///     from scratch), which is what "Product Form of the Inverse" refers to.
    /// This is a genuinely different computational method from the tableau
    /// approach (not just the same numbers relabelled) even though, for a
    /// non-degenerate problem, it reaches the same optimal solution.
    /// </summary>
    public class RevisedSimplexSolver : ISolver
    {
        public string Name => "Revised Primal Simplex Algorithm";

        private const double Epsilon = 1e-9;
        private const double BigM = 1_000_000d;
        private const int MaxIterations = 2000;

        /// <summary>Standard-form data built once up front; A/b/c never change - only B^-1 and the basis do.</summary>
        private sealed class StandardForm
        {
            public int M, N;
            public double[,] A = null!;   // M x N
            public double[] B = null!;    // length M
            public double[] C = null!;    // length N (already sign-adjusted for an internal MAX problem)
            public List<string> ColumnNames = null!;
            public List<bool> IsArtificial = null!;
            public List<VariableMapping> VariableMappings = null!;
            public int[] Basis = null!;   // length M, initial basic column per row
            public bool OriginalIsMinimization;
        }

        public SolveResult Solve(LPModel model, ResultLogger log)
        {
            log.WriteHeading(Name);

            var relaxation = ModelPreparation.BuildLpRelaxation(model);

            log.WriteSubHeading("Model being solved (LP, with implicit bounds made explicit)");
            log.WriteLine(relaxation.ToDisplayString());

            var sf = BuildStandardForm(relaxation);
            PrintCanonicalForm(log, sf);

            // B^-1 starts as the identity - the initial basis (slacks/artificials) IS the identity submatrix of A.
            var binv = Identity(sf.M);
            var basis = (int[])sf.Basis.Clone();

            int iteration = 0;
            while (true)
            {
                double[] xB = MultiplyMatrixVector(binv, sf.B);

                // ---- Price-Out step: simplex multipliers + reduced cost of every non-basic column ----
                double[] cB = basis.Select(col => sf.C[col]).ToArray();
                double[] y = MultiplyRowVectorMatrix(cB, binv); // y = c_B^T * B^-1, length M

                var basisSet = new HashSet<int>(basis);
                int enter = -1;
                var reducedCosts = new Dictionary<int, double>();

                for (int j = 0; j < sf.N; j++)
                {
                    if (basisSet.Contains(j)) continue;
                    double zj = 0;
                    for (int i = 0; i < sf.M; i++) zj += y[i] * sf.A[i, j];
                    double rc = sf.C[j] - zj;
                    reducedCosts[j] = rc;
                    if (enter == -1 && rc > Epsilon) enter = j; // Bland's rule: first improving column
                }

                LogPriceOut(log, iteration + 1, sf, y, reducedCosts, enter);

                if (enter == -1)
                    break; // optimal: no non-basic column can improve the objective

                // ---- price out the entering column through the current basis ----
                double[] d = new double[sf.M];
                for (int i = 0; i < sf.M; i++)
                {
                    double sum = 0;
                    for (int k = 0; k < sf.M; k++) sum += binv[i, k] * sf.A[k, enter];
                    d[i] = sum;
                }

                int leave = -1;
                double bestRatio = double.PositiveInfinity;
                for (int i = 0; i < sf.M; i++)
                {
                    if (d[i] > Epsilon)
                    {
                        double ratio = xB[i] / d[i];
                        if (ratio < bestRatio - Epsilon ||
                            (Math.Abs(ratio - bestRatio) <= Epsilon && (leave == -1 || basis[i] < basis[leave])))
                        {
                            bestRatio = ratio;
                            leave = i;
                        }
                    }
                }

                if (leave == -1)
                {
                    return SolveResult.Unbounded(Name,
                        $"Column '{sf.ColumnNames[enter]}' can increase without limit: the feasible region is unbounded.");
                }

                iteration++;
                string leavingName = sf.ColumnNames[basis[leave]];
                string enteringName = sf.ColumnNames[enter];

                // ---- Product Form step: update B^-1 via a single eta/elimination pass ----
                UpdateInverseProductForm(binv, d, leave);
                basis[leave] = enter;

                LogProductForm(log, iteration, sf, binv, basis, d, leave, enteringName, leavingName);

                if (iteration > MaxIterations)
                {
                    log.WriteLine("Iteration limit reached - aborting to avoid a possible infinite loop.");
                    break;
                }
            }

            // Feasibility check: an artificial variable left basic at a positive value means infeasible.
            var finalXB = MultiplyMatrixVector(binv, sf.B);
            for (int i = 0; i < sf.M; i++)
            {
                if (sf.IsArtificial[basis[i]] && finalXB[i] > 1e-6)
                {
                    var infeasible = SolveResult.Infeasible(Name,
                        "An artificial variable remains in the basis at a positive value: no feasible solution exists.");
                    PrimalSimplexSolver.ReportOutcome(log, infeasible, model);
                    return infeasible;
                }
            }

            var result = ExtractResult(sf, binv, basis, model);
            PrimalSimplexSolver.ReportOutcome(log, result, model);
            return result;
        }

        // =====================================================================
        // Standard-form construction (mirrors SimplexTableau.Build's sign-
        // restriction expansion and RHS-normalisation rules exactly, but emits
        // raw A/b/c arrays instead of a combined Big-M tableau).
        // =====================================================================
        private static StandardForm BuildStandardForm(LPModel model)
        {
            bool isMin = model.Sense == ObjectiveSense.Minimize;
            double sign = isMin ? -1.0 : 1.0;

            var mappings = new List<VariableMapping>();
            var colNames = new List<string>();
            var colCosts = new List<double>();
            var expansions = new List<(int col, double factor)[]>();

            for (int i = 0; i < model.VariableCount; i++)
            {
                var restriction = model.SignRestrictions[i];
                double objCoef = sign * model.ObjectiveCoefficients[i];
                string baseName = model.VariableNames[i];

                if (restriction == VariableRestriction.Negative)
                {
                    int col = colNames.Count;
                    colNames.Add(baseName);
                    colCosts.Add(-objCoef);
                    mappings.Add(new VariableMapping { Kind = MappingKind.Negated, ColumnIndex = col });
                    expansions.Add(new[] { (col, -1.0) });
                }
                else if (restriction == VariableRestriction.Unrestricted)
                {
                    int posCol = colNames.Count;
                    colNames.Add(baseName + "+");
                    colCosts.Add(objCoef);
                    int negCol = colNames.Count;
                    colNames.Add(baseName + "-");
                    colCosts.Add(-objCoef);
                    mappings.Add(new VariableMapping { Kind = MappingKind.Split, PositiveColumn = posCol, NegativeColumn = negCol });
                    expansions.Add(new[] { (posCol, 1.0), (negCol, -1.0) });
                }
                else
                {
                    int col = colNames.Count;
                    colNames.Add(baseName);
                    colCosts.Add(objCoef);
                    mappings.Add(new VariableMapping { Kind = MappingKind.Direct, ColumnIndex = col });
                    expansions.Add(new[] { (col, 1.0) });
                }
            }

            int decisionCols = colNames.Count;
            int m = model.Constraints.Count;

            var normalisedRows = new double[m][];
            var normalisedRhs = new double[m];
            var normalisedRelation = new RelationType[m];

            for (int r = 0; r < m; r++)
            {
                var constraint = model.Constraints[r];
                var row = new double[decisionCols];
                for (int i = 0; i < model.VariableCount; i++)
                    foreach (var (col, factor) in expansions[i])
                        row[col] += factor * constraint.Coefficients[i];

                double rhs = constraint.Rhs;
                var relation = constraint.Relation;
                if (rhs < 0)
                {
                    for (int j = 0; j < decisionCols; j++) row[j] = -row[j];
                    rhs = -rhs;
                    relation = relation switch
                    {
                        RelationType.LessOrEqual => RelationType.GreaterOrEqual,
                        RelationType.GreaterOrEqual => RelationType.LessOrEqual,
                        _ => RelationType.Equal
                    };
                }

                normalisedRows[r] = row;
                normalisedRhs[r] = rhs;
                normalisedRelation[r] = relation;
            }

            var basis = new int[m];
            var isArtificial = new List<bool>();
            for (int i = 0; i < decisionCols; i++) isArtificial.Add(false);

            var rowExtra = new List<(int slackCol, double slackCoef, int artCol)>();
            for (int r = 0; r < m; r++)
            {
                int slackCol = -1, artCol = -1;
                double slackCoef = 0;

                if (normalisedRelation[r] == RelationType.LessOrEqual)
                {
                    slackCol = colNames.Count;
                    colNames.Add($"s{r + 1}");
                    colCosts.Add(0);
                    isArtificial.Add(false);
                    slackCoef = 1.0;
                    basis[r] = slackCol;
                }
                else if (normalisedRelation[r] == RelationType.GreaterOrEqual)
                {
                    slackCol = colNames.Count;
                    colNames.Add($"s{r + 1}");
                    colCosts.Add(0);
                    isArtificial.Add(false);
                    slackCoef = -1.0;

                    artCol = colNames.Count;
                    colNames.Add($"a{r + 1}");
                    colCosts.Add(-BigM);
                    isArtificial.Add(true);
                    basis[r] = artCol;
                }
                else
                {
                    artCol = colNames.Count;
                    colNames.Add($"a{r + 1}");
                    colCosts.Add(-BigM);
                    isArtificial.Add(true);
                    basis[r] = artCol;
                }

                rowExtra.Add((slackCol, slackCoef, artCol));
            }

            int n = colNames.Count;
            var A = new double[m, n];
            var b = new double[m];

            for (int r = 0; r < m; r++)
            {
                for (int j = 0; j < decisionCols; j++) A[r, j] = normalisedRows[r][j];
                var (slackCol, slackCoef, artCol) = rowExtra[r];
                if (slackCol >= 0) A[r, slackCol] = slackCoef;
                if (artCol >= 0) A[r, artCol] = 1.0;
                b[r] = normalisedRhs[r];
            }

            var c = new double[n];
            for (int j = 0; j < n; j++) c[j] = colCosts[j];

            return new StandardForm
            {
                M = m,
                N = n,
                A = A,
                B = b,
                C = c,
                ColumnNames = colNames,
                IsArtificial = isArtificial,
                VariableMappings = mappings,
                Basis = basis,
                OriginalIsMinimization = isMin
            };
        }

        // =====================================================================
        // Linear algebra helpers
        // =====================================================================

        private static double[,] Identity(int size)
        {
            var m = new double[size, size];
            for (int i = 0; i < size; i++) m[i, i] = 1.0;
            return m;
        }

        private static double[] MultiplyMatrixVector(double[,] mat, double[] vec)
        {
            int rows = mat.GetLength(0), cols = mat.GetLength(1);
            var result = new double[rows];
            for (int i = 0; i < rows; i++)
            {
                double sum = 0;
                for (int j = 0; j < cols; j++) sum += mat[i, j] * vec[j];
                result[i] = sum;
            }
            return result;
        }

        private static double[] MultiplyRowVectorMatrix(double[] rowVec, double[,] mat)
        {
            int rows = mat.GetLength(0), cols = mat.GetLength(1);
            var result = new double[cols];
            for (int k = 0; k < cols; k++)
            {
                double sum = 0;
                for (int i = 0; i < rows; i++) sum += rowVec[i] * mat[i, k];
                result[k] = sum;
            }
            return result;
        }

        /// <summary>
        /// Updates B^-1 in place using the Product Form of the Inverse: a single
        /// eta-vector elimination pass (mathematically equivalent to
        /// B^-1_new = E * B^-1_old for an eta matrix E built from the priced-out
        /// column d), rather than recomputing the inverse of the new basis from scratch.
        /// </summary>
        private static void UpdateInverseProductForm(double[,] binv, double[] d, int pivotRow)
        {
            int m = d.Length;
            double pivot = d[pivotRow];

            for (int k = 0; k < m; k++) binv[pivotRow, k] /= pivot;

            for (int i = 0; i < m; i++)
            {
                if (i == pivotRow) continue;
                double factor = d[i];
                if (Math.Abs(factor) < Epsilon) continue;
                for (int k = 0; k < m; k++)
                    binv[i, k] -= factor * binv[pivotRow, k];
            }
        }

        private static SolveResult ExtractResult(StandardForm sf, double[,] binv, int[] basis, LPModel model)
        {
            var xB = MultiplyMatrixVector(binv, sf.B);
            var columnValues = new double[sf.N];
            for (int i = 0; i < sf.M; i++) columnValues[basis[i]] = xB[i];

            var values = new double[sf.VariableMappings.Count];
            for (int i = 0; i < sf.VariableMappings.Count; i++)
                values[i] = ResultLogger.Round3(sf.VariableMappings[i].Recover(columnValues));

            double objectiveInternal = 0;
            for (int i = 0; i < sf.M; i++) objectiveInternal += sf.C[basis[i]] * xB[i];
            double objective = sf.OriginalIsMinimization ? -objectiveInternal : objectiveInternal;

            return new SolveResult
            {
                Status = SolutionStatus.Optimal,
                VariableValues = values,
                ObjectiveValue = ResultLogger.Round3(objective),
                AlgorithmName = "Revised Primal Simplex Algorithm",
                Message = "Optimal solution found."
            };
        }

        // =====================================================================
        // Logging
        // =====================================================================

        private static void PrintCanonicalForm(ResultLogger log, StandardForm sf)
        {
            log.WriteSubHeading("Canonical Form (standard form used by the revised method)");
            var headers = sf.ColumnNames.Append("RHS").ToArray();
            var rowLabels = new List<string>();
            var display = new double[sf.M, sf.N + 1];
            for (int r = 0; r < sf.M; r++)
            {
                rowLabels.Add(sf.ColumnNames[sf.Basis[r]]);
                for (int j = 0; j < sf.N; j++) display[r, j] = sf.A[r, j];
                display[r, sf.N] = sf.B[r];
            }
            log.WriteTable(headers, rowLabels, display);
            log.WriteLine("Objective (internal, maximised form): " + string.Join(" ", sf.ColumnNames.Select((n, j) => $"{ResultLogger.Fmt(sf.C[j])}*{n}")));
        }

        private static void LogPriceOut(ResultLogger log, int iterationNumber, StandardForm sf,
            double[] y, Dictionary<int, double> reducedCosts, int entering)
        {
            log.WriteSubHeading($"Iteration {iterationNumber} - Price-Out");
            log.WriteLine("Simplex multipliers y = c_B^T * B^-1:");
            log.WriteLine("  y = [" + string.Join(", ", y.Select(ResultLogger.Fmt)) + "]");
            log.WriteLine("Reduced cost of every non-basic column (c_j - y . A_j):");
            foreach (var kvp in reducedCosts.OrderBy(k => k.Key))
                log.WriteLine($"  {sf.ColumnNames[kvp.Key]}: {ResultLogger.Fmt(kvp.Value)}");

            log.WriteLine(entering == -1
                ? "No column has a positive reduced cost - current basis is optimal."
                : $"Entering column (first positive reduced cost, Bland's rule): {sf.ColumnNames[entering]}");
        }

        private static void LogProductForm(ResultLogger log, int iterationNumber, StandardForm sf,
            double[,] binv, int[] basis, double[] d, int pivotRow, string entering, string leaving)
        {
            log.WriteSubHeading($"Iteration {iterationNumber} - Product Form of the Inverse");
            log.WriteLine($"Entering: {entering}, Leaving: {leaving} (pivot row {pivotRow})");
            log.WriteLine("Priced-out column d = B^-1 * A_entering:");
            log.WriteLine("  d = [" + string.Join(", ", d.Select(ResultLogger.Fmt)) + "]");

            log.WriteLine("Updated B^-1:");
            var headers = Enumerable.Range(1, sf.M).Select(i => $"col{i}").ToArray();
            var rowLabels = Enumerable.Range(1, sf.M).Select(i => $"row{i}").ToList();
            log.WriteTable(headers, rowLabels, binv);

            log.WriteLine("Current basis: " + string.Join(", ", basis.Select(col => sf.ColumnNames[col])));
        }
    }
}
