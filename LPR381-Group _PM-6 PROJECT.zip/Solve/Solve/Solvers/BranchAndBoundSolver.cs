using System;
using System.Collections.Generic;
using Solve.IO;
using Solve.Models;

namespace Solve.Solvers
{
    /// <summary>
    /// Solves an Integer/Binary Programming model with the Branch &amp; Bound
    /// Simplex Algorithm:
    ///   1. Solve the LP relaxation of the root problem with the Big-M Primal
    ///      Simplex method (full canonical form + every tableau iteration logged).
    ///   2. If every integer/binary variable is already integral, that node IS
    ///      a candidate solution.
    ///   3. Otherwise pick a fractional integer/binary variable and create TWO
    ///      new sub-problems ("branches"): one with `x &lt;= floor(value)` added,
    ///      one with `x &gt;= ceil(value)` added, and push both onto a stack.
    ///   4. Repeat, popping sub-problems (depth-first, so the search naturally
    ///      backtracks once a branch is exhausted) until the stack is empty.
    ///
    /// Every node fathoms for one of three reasons, all logged explicitly:
    ///   - Infeasible / unbounded relaxation.
    ///   - Bound: the relaxation's objective cannot beat the current best
    ///     integer candidate, so branching further is pointless.
    ///   - Integrality: the relaxation is already an integer solution - a new candidate.
    /// The best candidate found across the whole tree is the optimal integer solution.
    /// </summary>
    public class BranchAndBoundSolver : ISolver
    {
        public string Name => "Branch & Bound Simplex Algorithm";

        private const double IntegerTolerance = 1e-6;
        private const int MaxNodes = 5000;

        public SolveResult Solve(LPModel model, ResultLogger log)
        {
            log.WriteHeading(Name);

            if (!model.HasIntegerRestrictions)
            {
                log.WriteLine("No 'int' or 'bin' variables were declared - solving as a plain LP relaxation.");
                var plain = ModelPreparation.BuildLpRelaxation(model);
                var plainTableau = SimplexTableau.Build(plain);
                var plainResult = plainTableau.RunPrimalSimplex(log, Name, model);
                PrimalSimplexSolver.ReportOutcome(log, plainResult, model);
                return plainResult;
            }

            bool isMax = model.Sense == ObjectiveSense.Maximize;
            var root = ModelPreparation.BuildLpRelaxation(model); // 'bin' -> Integer + explicit x<=1 bound

            var stack = new Stack<LPModel>();
            stack.Push(root);

            double bestObjective = isMax ? double.NegativeInfinity : double.PositiveInfinity;
            SolveResult? bestResult = null;
            int nodeCount = 0;

            while (stack.Count > 0)
            {
                if (nodeCount >= MaxNodes)
                {
                    log.WriteLine($"Reached the node cap ({MaxNodes}) without exhausting the tree - stopping the search early.");
                    break;
                }

                var node = stack.Pop();
                nodeCount++;

                log.WriteSubHeading($"Node {nodeCount}: sub-problem being evaluated");
                log.WriteLine(node.ToDisplayString());

                var tableau = SimplexTableau.Build(node);
                var result = tableau.RunPrimalSimplex(log, $"{Name} (Node {nodeCount})", model);

                if (result.Status == SolutionStatus.Infeasible)
                {
                    log.WriteLine($"Node {nodeCount} FATHOMED: relaxation is infeasible.");
                    continue;
                }
                if (result.Status == SolutionStatus.Unbounded)
                {
                    log.WriteLine($"Node {nodeCount} FATHOMED: relaxation is unbounded.");
                    continue;
                }

                bool cannotImprove = bestResult != null &&
                    (isMax ? result.ObjectiveValue <= bestObjective + 1e-9
                           : result.ObjectiveValue >= bestObjective - 1e-9);
                if (cannotImprove)
                {
                    log.WriteLine($"Node {nodeCount} FATHOMED by bound: relaxation z = {ResultLogger.Fmt(result.ObjectiveValue)} " +
                                  $"cannot beat the current best candidate z = {ResultLogger.Fmt(bestObjective)}.");
                    continue;
                }

                int branchVar = FindFractionalIntegerVariable(model, result, out double branchValue);

                if (branchVar == -1)
                {
                    bestObjective = result.ObjectiveValue;
                    bestResult = result;
                    log.WriteLine($"*** Node {nodeCount} FATHOMED by integrality: NEW BEST CANDIDATE, " +
                                  $"z = {ResultLogger.Fmt(result.ObjectiveValue)} ***");
                    continue;
                }

                log.WriteLine($"Node {nodeCount}: branching on {model.VariableNames[branchVar]} = {ResultLogger.Fmt(branchValue)} " +
                              $"(not integral) - creating two sub-problems.");

                var floorChild = node.Clone();
                var floorCoeffs = new List<double>(new double[model.VariableCount]);
                floorCoeffs[branchVar] = 1.0;
                floorChild.Constraints.Add(new Constraint(floorCoeffs, RelationType.LessOrEqual, Math.Floor(branchValue)));

                var ceilChild = node.Clone();
                var ceilCoeffs = new List<double>(new double[model.VariableCount]);
                ceilCoeffs[branchVar] = 1.0;
                ceilChild.Constraints.Add(new Constraint(ceilCoeffs, RelationType.GreaterOrEqual, Math.Ceiling(branchValue)));

                // Push both branches; being a stack, whichever is pushed LAST is explored
                // FIRST - this is what gives the search its depth-first backtracking behaviour.
                stack.Push(ceilChild);
                stack.Push(floorChild);
            }

            log.WriteSubHeading("Branch & Bound Simplex - Search Complete");
            log.WriteLine($"Total sub-problems (nodes) explored: {nodeCount}");

            if (bestResult == null)
            {
                var infeasible = SolveResult.Infeasible(Name, "No integer-feasible solution was found in any explored branch.");
                PrimalSimplexSolver.ReportOutcome(log, infeasible, model);
                return infeasible;
            }

            bestResult.AlgorithmName = Name;
            bestResult.Message = $"Optimal integer solution found (best candidate across {nodeCount} explored sub-problems).";
            log.WriteSubHeading("Best Candidate (Optimal Integer Solution)");
            PrimalSimplexSolver.ReportOutcome(log, bestResult, model);
            return bestResult;
        }

        /// <summary>
        /// Finds the first integer/binary-restricted original variable whose
        /// current relaxation value is fractional. Returns -1 if every
        /// integer-restricted variable already holds an integer value.
        /// </summary>
        private static int FindFractionalIntegerVariable(LPModel model, SolveResult result, out double branchValue)
        {
            for (int i = 0; i < model.VariableCount; i++)
            {
                var restriction = model.SignRestrictions[i];
                if (restriction != VariableRestriction.Integer && restriction != VariableRestriction.Binary) continue;

                double value = result.VariableValues[i];
                double frac = value - Math.Floor(value);
                if (frac > IntegerTolerance && frac < 1 - IntegerTolerance)
                {
                    branchValue = value;
                    return i;
                }
            }

            branchValue = 0;
            return -1;
        }
    }
}
