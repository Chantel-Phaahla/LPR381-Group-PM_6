using System;
using System.Collections.Generic;
using System.Linq;
using Solve.IO;
using Solve.Models;

namespace Solve.Solvers
{
    /// <summary>
    /// Solves a single-constraint 0/1 Knapsack model (every variable 'bin', one
    /// '&lt;=' capacity constraint, maximisation) with the classic Branch &amp;
    /// Bound Knapsack Algorithm - deliberately NOT simplex-based, since this is
    /// meant to be a distinct, more specialised algorithm from "Branch &amp;
    /// Bound Simplex":
    ///
    ///   1. Sort items by value/weight ratio, descending (the greedy order that
    ///      gives the tightest possible fractional-relaxation bound).
    ///   2. Depth-first search a binary decision tree (include / exclude each
    ///      item in ratio order), using a stack so the search naturally
    ///      backtracks once a branch is exhausted.
    ///   3. Bound each node with the fractional knapsack relaxation of the
    ///      remaining capacity and remaining (unfixed) items - fill items
    ///      whole, in ratio order, until one item only partially fits.
    ///   4. Fathom a node when: its weight already exceeds capacity
    ///      (infeasible), its bound cannot beat the current best candidate
    ///      (bound), or every item has been decided (a complete candidate).
    /// </summary>
    public class KnapsackBranchAndBoundSolver : ISolver
    {
        public string Name => "Branch & Bound Knapsack Algorithm";

        private const double Eps = 1e-9;
        private const int MaxNodes = 200_000;

        private sealed class KnapsackNode
        {
            public int Level;          // position within the ratio-sorted item order
            public double Weight;
            public double Value;
            public bool[] Included = Array.Empty<bool>(); // indexed by ORIGINAL variable index
        }

        public SolveResult Solve(LPModel model, ResultLogger log)
        {
            log.WriteHeading(Name);

            if (!IsKnapsackShaped(model, out string reason))
            {
                log.WriteLine($"This algorithm only applies to a single-constraint, maximising 0/1 Knapsack model: {reason}");
                log.WriteLine("Use the Branch & Bound Simplex Algorithm instead for general integer models.");
                return new SolveResult
                {
                    Status = SolutionStatus.NotSolved,
                    AlgorithmName = Name,
                    Message = reason
                };
            }

            int n = model.VariableCount;
            double capacity = model.Constraints[0].Rhs;
            double[] weights = model.Constraints[0].Coefficients.ToArray();
            double[] values = model.ObjectiveCoefficients.ToArray();

            log.WriteSubHeading("Model");
            log.WriteLine(model.ToDisplayString());
            log.WriteLine($"Capacity: {ResultLogger.Fmt(capacity)}");

            // ---- Step 1: sort items by value/weight ratio, descending ----
            int[] sortedOrder = Enumerable.Range(0, n)
                .OrderByDescending(i => weights[i] > Eps ? values[i] / weights[i] : double.PositiveInfinity)
                .ToArray();

            log.WriteSubHeading("Items sorted by value/weight ratio (descending)");
            foreach (int i in sortedOrder)
            {
                double ratio = weights[i] > Eps ? values[i] / weights[i] : double.PositiveInfinity;
                log.WriteLine($"  {model.VariableNames[i]}: value = {ResultLogger.Fmt(values[i])}, weight = {ResultLogger.Fmt(weights[i])}, ratio = {ResultLogger.Fmt(ratio)}");
            }

            // ---- Step 2..4: depth-first branch & bound ----
            var stack = new Stack<KnapsackNode>();
            stack.Push(new KnapsackNode { Level = 0, Weight = 0, Value = 0, Included = new bool[n] });

            double bestValue = double.NegativeInfinity;
            bool[]? bestIncluded = null;
            int nodeCount = 0;

            while (stack.Count > 0)
            {
                if (nodeCount >= MaxNodes)
                {
                    log.WriteLine($"Reached the node cap ({MaxNodes}) without exhausting the tree - stopping the search early.");
                    break;
                }

                var node = stack.Pop();
                nodeCount++;

                log.WriteSubHeading($"Node {nodeCount}: level {node.Level}/{n}, weight so far = {ResultLogger.Fmt(node.Weight)}, value so far = {ResultLogger.Fmt(node.Value)}");

                if (node.Weight > capacity + Eps)
                {
                    log.WriteLine($"Node {nodeCount} FATHOMED: infeasible (weight {ResultLogger.Fmt(node.Weight)} exceeds capacity {ResultLogger.Fmt(capacity)}).");
                    continue;
                }

                double bound = FractionalBound(node, sortedOrder, weights, values, capacity);

                if (node.Level == n)
                {
                    if (node.Value > bestValue + Eps)
                    {
                        bestValue = node.Value;
                        bestIncluded = (bool[])node.Included.Clone();
                        log.WriteLine($"*** Node {nodeCount} FATHOMED by completion: NEW BEST CANDIDATE, value = {ResultLogger.Fmt(bestValue)} ***");
                    }
                    else
                    {
                        log.WriteLine($"Node {nodeCount} FATHOMED by completion: value {ResultLogger.Fmt(node.Value)} does not beat the current best {ResultLogger.Fmt(bestValue)}.");
                    }
                    continue;
                }

                if (bound <= bestValue + Eps)
                {
                    log.WriteLine($"Node {nodeCount} FATHOMED by bound: best possible value from here ({ResultLogger.Fmt(bound)}) " +
                                  $"cannot beat the current best candidate ({ResultLogger.Fmt(bestValue)}).");
                    continue;
                }

                int itemIndex = sortedOrder[node.Level];
                log.WriteLine($"Node {nodeCount}: bound = {ResultLogger.Fmt(bound)} (still promising) - branching on {model.VariableNames[itemIndex]}.");

                // Branch 1: EXCLUDE this item.
                var excludeNode = new KnapsackNode
                {
                    Level = node.Level + 1,
                    Weight = node.Weight,
                    Value = node.Value,
                    Included = (bool[])node.Included.Clone()
                };

                // Branch 2: INCLUDE this item (only meaningful to create if it doesn't
                // immediately blow the capacity - still pushed either way so the next
                // pop's own infeasibility check logs and fathoms it consistently).
                var includedFlags = (bool[])node.Included.Clone();
                includedFlags[itemIndex] = true;
                var includeNode = new KnapsackNode
                {
                    Level = node.Level + 1,
                    Weight = node.Weight + weights[itemIndex],
                    Value = node.Value + values[itemIndex],
                    Included = includedFlags
                };

                // Push EXCLUDE first, INCLUDE last: since this is a stack (LIFO), INCLUDE
                // is explored first - the standard "try including the best-ratio item
                // first" depth-first strategy, with EXCLUDE remaining on the stack to be
                // backtracked into once that branch is exhausted.
                stack.Push(excludeNode);
                stack.Push(includeNode);
            }

            log.WriteSubHeading("Branch & Bound Knapsack - Search Complete");
            log.WriteLine($"Total sub-problems (nodes) explored: {nodeCount}");

            if (bestIncluded == null)
            {
                var infeasible = SolveResult.Infeasible(Name, "No feasible 0/1 selection of items was found within capacity.");
                PrimalSimplexSolver.ReportOutcome(log, infeasible, model);
                return infeasible;
            }

            var values3 = bestIncluded.Select(b => b ? 1.0 : 0.0).ToArray();
            var result = new SolveResult
            {
                Status = SolutionStatus.Optimal,
                VariableValues = values3,
                ObjectiveValue = ResultLogger.Round3(bestValue),
                AlgorithmName = Name,
                Message = $"Optimal 0/1 knapsack selection found (best candidate across {nodeCount} explored sub-problems)."
            };

            log.WriteSubHeading("Best Candidate (Optimal Knapsack Selection)");
            PrimalSimplexSolver.ReportOutcome(log, result, model);
            return result;
        }

        /// <summary>
        /// Fractional-knapsack upper bound for everything from <paramref name="node"/>'s
        /// current level onward: fill remaining capacity with whole items in ratio
        /// order, then take a fractional slice of the first item that doesn't fully fit.
        /// This is always an upper bound on any integer completion of this node.
        /// </summary>
        private static double FractionalBound(KnapsackNode node, int[] sortedOrder, double[] weights, double[] values, double capacity)
        {
            double bound = node.Value;
            double remaining = capacity - node.Weight;
            if (remaining < -Eps) return node.Value; // already infeasible; bound is moot

            for (int k = node.Level; k < sortedOrder.Length; k++)
            {
                int idx = sortedOrder[k];
                if (weights[idx] <= remaining + Eps)
                {
                    remaining -= weights[idx];
                    bound += values[idx];
                }
                else
                {
                    if (weights[idx] > Eps)
                        bound += values[idx] * (remaining / weights[idx]);
                    break;
                }
            }

            return bound;
        }

        private static bool IsKnapsackShaped(LPModel model, out string reason)
        {
            if (model.Constraints.Count != 1)
            {
                reason = "the model must have exactly one constraint.";
                return false;
            }
            if (model.Constraints[0].Relation != RelationType.LessOrEqual)
            {
                reason = "the single constraint must use '<='.";
                return false;
            }
            if (model.SignRestrictions.Any(r => r != VariableRestriction.Binary))
            {
                reason = "every decision variable must be declared 'bin'.";
                return false;
            }
            if (model.Sense != ObjectiveSense.Maximize)
            {
                reason = "the classic knapsack algorithm assumes a maximisation objective.";
                return false;
            }

            reason = string.Empty;
            return true;
        }
    }
}
