using System;
using System.Collections.Generic;
using Solve.IO;
using Solve.Models;

namespace Solve.Solvers
{
    /// <summary>
    /// Solves an Integer Programming (or Binary Integer Programming) model with
    /// the Cutting Plane Algorithm:
    ///   1. Solve the LP relaxation with the Big-M Primal Simplex method.
    ///   2. While some integer-restricted variable is fractional, derive a Gomory
    ///      fractional cut from the "most fractional" basic row, append it to the
    ///      tableau, and restore optimality with the Dual Simplex Algorithm.
    ///   3. Stop when every integer-restricted variable is integral (optimal
    ///      integer solution found) or a cut proves the model infeasible.
    ///
    /// Every relaxation tableau, every added cut, and every re-optimisation
    /// iteration is written to the log, satisfying the "display the Canonical
    /// Form and all iterations" requirement for this algorithm.
    /// </summary>
    public class CuttingPlaneSolver : ISolver
    {
        public string Name => "Cutting Plane Algorithm";

        private const double IntegerTolerance = 1e-6;
        private const int MaxCuts = 200;

        public SolveResult Solve(LPModel model, ResultLogger log)
        {
            log.WriteHeading(Name);

            if (!model.HasIntegerRestrictions)
            {
                log.WriteLine("No 'int' or 'bin' variables were declared - solving as a plain LP.");
            }

            var relaxation = ModelPreparation.BuildLpRelaxation(model);

            log.WriteSubHeading("LP Relaxation being solved (implicit bounds made explicit)");
            log.WriteLine(relaxation.ToDisplayString());

            var tableau = SimplexTableau.Build(relaxation);
            var relaxationResult = tableau.RunPrimalSimplex(log, Name + " - LP Relaxation", model);

            if (relaxationResult.Status != SolutionStatus.Optimal)
            {
                // Infeasible/unbounded is inherited directly from the relaxation:
                // an infeasible/unbounded relaxation makes the IP infeasible/unbounded too.
                PrimalSimplexSolver.ReportOutcome(log, relaxationResult, model);
                relaxationResult.AlgorithmName = Name;
                return relaxationResult;
            }

            // Identify which tableau column corresponds to each integer/binary variable.
            var integerColumns = new List<int>();
            for (int i = 0; i < model.VariableCount; i++)
            {
                var r = model.SignRestrictions[i];
                if (r != VariableRestriction.Integer && r != VariableRestriction.Binary) continue;

                var mapping = tableau.VariableMappings[i];
                if (mapping.Kind == MappingKind.Direct) integerColumns.Add(mapping.ColumnIndex);
                else if (mapping.Kind == MappingKind.Negated) integerColumns.Add(mapping.ColumnIndex);
                // Split (urs + int together) is an unusual combination; not handled by
                // this cutting-plane implementation - flagged to the user below if it occurs.
            }

            if (integerColumns.Count == 0)
            {
                log.WriteLine("No variable requires integrality at the tableau level - the LP-relaxation optimum is already the answer.");
                relaxationResult.AlgorithmName = Name;
                return relaxationResult;
            }

            int cutCount = 0;
            while (true)
            {
                int sourceRow = FindMostFractionalRow(tableau, integerColumns, out double worstFraction);

                if (sourceRow == -1)
                {
                    log.WriteSubHeading("All integer-restricted variables are now integral - optimal integer solution reached.");
                    break;
                }

                if (cutCount >= MaxCuts)
                {
                    log.WriteLine($"Reached the maximum number of cuts ({MaxCuts}) without an all-integer solution; stopping.");
                    break;
                }

                cutCount++;
                string sourceVarName = tableau.ColumnNames[tableau.BasicColumnOfRow[sourceRow - 1]];
                log.WriteSubHeading($"Cut #{cutCount}: derived from row of basic variable '{sourceVarName}' " +
                                     $"(fractional part = {ResultLogger.Fmt(worstFraction)})");

                tableau.AddGomoryCut(sourceRow, cutCount);
                tableau.Print(log, $"Tableau after adding cut #{cutCount} (primal-infeasible - restoring feasibility next)");

                bool feasible = tableau.RunDualSimplexToFeasibility(log);
                if (!feasible)
                {
                    var infeasible = SolveResult.Infeasible(Name,
                        "A Gomory cut proved that no integer-feasible solution exists (dual simplex could not restore feasibility).");
                    PrimalSimplexSolver.ReportOutcome(log, infeasible, model);
                    return infeasible;
                }

                tableau.Print(log, $"Tableau after re-optimising following cut #{cutCount}");
            }

            var finalResult = tableau.ExtractResult(Name, model);
            PrimalSimplexSolver.ReportOutcome(log, finalResult, model);
            return finalResult;
        }

        /// <summary>
        /// Chooses the source row for the next cut: among all integer-restricted
        /// variables that are currently basic with a fractional value, picks the
        /// one whose fractional part is closest to 0.5 (the classic "most
        /// fractional" heuristic, which tends to cut off the largest infeasible region).
        /// </summary>
        private static int FindMostFractionalRow(SimplexTableau tableau, List<int> integerColumns, out double worstFraction)
        {
            int bestRow = -1;
            double bestDistanceFromHalf = double.PositiveInfinity;
            worstFraction = 0;

            foreach (int col in integerColumns)
            {
                int row = tableau.BasicRowOfColumn(col);
                if (row == -1) continue; // non-basic => value 0, already integral

                double value = tableau.Data[row, tableau.RhsIndex];
                double frac = value - Math.Floor(value);
                if (frac < IntegerTolerance || frac > 1 - IntegerTolerance) continue; // already (near) integral

                double distanceFromHalf = Math.Abs(frac - 0.5);
                if (distanceFromHalf < bestDistanceFromHalf)
                {
                    bestDistanceFromHalf = distanceFromHalf;
                    bestRow = row;
                    worstFraction = frac;
                }
            }

            return bestRow;
        }
    }
}
