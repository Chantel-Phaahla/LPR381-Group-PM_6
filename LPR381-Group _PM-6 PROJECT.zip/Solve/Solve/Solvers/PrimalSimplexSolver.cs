using Solve.IO;
using Solve.Models;

namespace Solve.Solvers
{
    /// <summary>
    /// Solves a Linear Programming model with the (tableau-based) Big-M Primal
    /// Simplex Algorithm, displaying the canonical form and every tableau
    /// iteration. Binary variables are automatically bounded (x &lt;= 1) so that
    /// the Knapsack IP from the brief can be solved as a plain LP relaxation
    /// (integrality itself is then the job of Cutting Plane / Branch &amp; Bound).
    /// </summary>
    public class PrimalSimplexSolver : ISolver
    {
        public string Name => "Primal Simplex Algorithm";

        public SolveResult Solve(LPModel model, ResultLogger log)
        {
            log.WriteHeading(Name);

            var relaxation = ModelPreparation.BuildLpRelaxation(model);

            log.WriteSubHeading("Model being solved (LP, with implicit bounds made explicit)");
            log.WriteLine(relaxation.ToDisplayString());

            var tableau = SimplexTableau.Build(relaxation);
            var result = tableau.RunPrimalSimplex(log, Name, model);

            ReportOutcome(log, result, model);
            return result;
        }

        /// <summary>Shared, human-friendly summary written after ANY simplex-family run finishes.</summary>
        public static void ReportOutcome(ResultLogger log, SolveResult result, LPModel originalModel)
        {
            log.WriteSubHeading("Result");
            switch (result.Status)
            {
                case SolutionStatus.Optimal:
                    for (int i = 0; i < result.VariableValues.Length; i++)
                        log.WriteLine($"  {originalModel.VariableNames[i]} = {ResultLogger.Fmt(result.VariableValues[i])}");
                    log.WriteLine($"  Objective value (z) = {ResultLogger.Fmt(result.ObjectiveValue)}");
                    break;
                case SolutionStatus.Infeasible:
                    log.WriteLine("  The model is INFEASIBLE.");
                    log.WriteLine($"  Reason: {result.Message}");
                    break;
                case SolutionStatus.Unbounded:
                    log.WriteLine("  The model is UNBOUNDED.");
                    log.WriteLine($"  Reason: {result.Message}");
                    break;
                default:
                    log.WriteLine("  The model could not be solved.");
                    break;
            }
        }
    }
}
