using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Solve.IO
{
    /// <summary>
    /// Central place through which every solver and every sensitivity-analysis
    /// operation writes its output. Everything written here is simultaneously:
    ///   1. echoed to the console (so the user sees progress live), and
    ///   2. buffered so it can be flushed to the results output text file.
    ///
    /// Keeping a single logger means the "display canonical form / all tableau
    /// iterations" requirement and the "export results to output file" requirement
    /// are always satisfied together, from one call site.
    /// </summary>
    public class ResultLogger
    {
        private readonly StringBuilder _buffer = new();
        private readonly bool _echoToConsole;

        /// <summary>
        /// Raised once per <see cref="WriteLine"/> call, in addition to (and independently
        /// of) the console echo and the in-memory buffer. This is what lets a GUI front
        /// end (e.g. the WPF app) stream tableau iterations into a live log panel as a
        /// solver produces them, without the solver/IO layer knowing anything about the UI.
        /// </summary>
        public event Action<string>? LineWritten;

        public ResultLogger(bool echoToConsole = true)
        {
            _echoToConsole = echoToConsole;
        }

        public void WriteLine(string text = "")
        {
            _buffer.AppendLine(text);
            if (_echoToConsole) Console.WriteLine(text);
            LineWritten?.Invoke(text);
        }

        public void WriteHeading(string title)
        {
            string bar = new string('=', Math.Max(title.Length + 4, 40));
            WriteLine();
            WriteLine(bar);
            WriteLine($"  {title}");
            WriteLine(bar);
        }

        public void WriteSubHeading(string title)
        {
            WriteLine();
            WriteLine($"--- {title} ---");
        }

        /// <summary>Rounds any decimal value to 3 decimal places, as required by the output file format.</summary>
        public static double Round3(double value) => Math.Round(value, 3, MidpointRounding.AwayFromZero);

        public static string Fmt(double value) => Round3(value).ToString("0.###");

        /// <summary>Writes a numeric matrix (a simplex tableau) as a neatly aligned table.</summary>
        public void WriteTable(string[] columnHeaders, IEnumerable<string> rowLabels, double[,] data)
        {
            int rows = data.GetLength(0);
            int cols = data.GetLength(1);
            var labels = rowLabels.ToList();

            var formattedCells = new string[rows, cols];
            for (int r = 0; r < rows; r++)
                for (int c = 0; c < cols; c++)
                    formattedCells[r, c] = Fmt(data[r, c]);

            int labelWidth = Math.Max(6, labels.Count == 0 ? 6 : labels.Max(l => l.Length));
            var colWidths = new int[cols];
            for (int c = 0; c < cols; c++)
            {
                int header = c < columnHeaders.Length ? columnHeaders[c].Length : 0;
                int maxCell = 0;
                for (int r = 0; r < rows; r++) maxCell = Math.Max(maxCell, formattedCells[r, c].Length);
                colWidths[c] = Math.Max(header, maxCell) + 2;
            }

            var headerLine = new StringBuilder(new string(' ', labelWidth + 2));
            for (int c = 0; c < cols; c++)
            {
                string h = c < columnHeaders.Length ? columnHeaders[c] : $"c{c}";
                headerLine.Append(h.PadLeft(colWidths[c]));
            }
            WriteLine(headerLine.ToString());

            for (int r = 0; r < rows; r++)
            {
                string label = r < labels.Count ? labels[r] : $"R{r}";
                var line = new StringBuilder(label.PadRight(labelWidth + 2));
                for (int c = 0; c < cols; c++)
                    line.Append(formattedCells[r, c].PadLeft(colWidths[c]));
                WriteLine(line.ToString());
            }
        }

        public string GetBuffer() => _buffer.ToString();

        public void ClearBuffer() => _buffer.Clear();

        /// <summary>Appends the current buffer to the given output text file (creating it if necessary).</summary>
        public void FlushToFile(string path, bool append = true)
        {
            try
            {
                if (append)
                    File.AppendAllText(path, _buffer.ToString());
                else
                    File.WriteAllText(path, _buffer.ToString());
            }
            catch (Exception ex)
            {
                throw new IOException($"Failed to write results to output file '{path}': {ex.Message}", ex);
            }
        }
    }
}
