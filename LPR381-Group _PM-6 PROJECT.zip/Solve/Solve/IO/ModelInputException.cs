using System;

namespace Solve.IO
{
    /// <summary>
    /// Thrown whenever the input text file does not conform to the required
    /// grammar. Carries the offending line number so the user can find and
    /// fix the problem quickly instead of receiving a generic crash.
    /// </summary>
    public class ModelInputException : Exception
    {
        public int? LineNumber { get; }

        public ModelInputException(string message, int? lineNumber = null)
            : base(FormatMessage(message, lineNumber))
        {
            LineNumber = lineNumber;
        }

        private static string FormatMessage(string message, int? lineNumber) =>
            lineNumber.HasValue ? $"Line {lineNumber}: {message}" : message;
    }
}
