using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Solve.Models;

namespace Solve.IO
{
    /// <summary>
    /// Reads the plain-text model description described in the assignment brief
    /// and turns it into a validated <see cref="LPModel"/>.
    ///
    /// Expected grammar (whitespace separated):
    ///   Line 1        : max|min  {+|-}{number} ...            (objective function)
    ///   Line 2..n-1   : {+|-}{number} ...  {&lt;=|&gt;=|=}{number}   (one line per constraint)
    ///   Last line     : {+|-|urs|int|bin} ...                 (sign restrictions, one per variable)
    ///
    /// Every validation failure raises a <see cref="ModelInputException"/> that
    /// reports the offending line number and a human readable reason, so a user
    /// can fix a malformed file instead of the program crashing outright.
    /// </summary>
    public static class InputParser
    {
        // A signed coefficient, e.g. "+2", "-3.5"
        private static readonly Regex SignedNumber = new(@"^([+-])(\d+(\.\d+)?)$", RegexOptions.Compiled);

        // A relation glued to its right-hand-side, e.g. "<=40", ">=10", "=15", "=-4"
        private static readonly Regex RelationRhs = new(@"^(<=|>=|=)([+-]?\d+(\.\d+)?)$", RegexOptions.Compiled);

        private static readonly HashSet<string> RestrictionTokens = new(StringComparer.OrdinalIgnoreCase)
        {
            "+", "-", "urs", "int", "bin"
        };

        public static LPModel ParseFile(string path)
        {
            if (!File.Exists(path))
                throw new ModelInputException($"Input file not found: '{path}'.");

            string[] rawLines;
            try
            {
                rawLines = File.ReadAllLines(path);
            }
            catch (Exception ex)
            {
                throw new ModelInputException($"Could not read input file: {ex.Message}");
            }

            return ParseLines(rawLines);
        }

        /// <summary>
        /// Parses a model from an in-memory block of text using the exact same grammar
        /// and validation as <see cref="ParseFile"/>. Used e.g. by the "load bundled
        /// example" shortcut in the UI, where there is no file on disk to read from.
        /// </summary>
        public static LPModel ParseText(string text)
        {
            var rawLines = (text ?? string.Empty).Replace("\r\n", "\n").Split('\n');
            return ParseLines(rawLines);
        }

        private static LPModel ParseLines(string[] rawLines)
        {
            // Strip blank lines but remember original 1-based line numbers for error reporting.
            var lines = new List<(int Number, string Text)>();
            for (int i = 0; i < rawLines.Length; i++)
            {
                var trimmed = rawLines[i].Trim();
                if (trimmed.Length > 0)
                    lines.Add((i + 1, trimmed));
            }

            if (lines.Count < 3)
                throw new ModelInputException(
                    "The input file must contain at least an objective line, one constraint line, " +
                    "and a sign-restriction line.");

            // ---- Line 1: objective function -----------------------------------------
            var (objSense, objCoefficients) = ParseObjectiveLine(lines[0]);
            int varCount = objCoefficients.Count;

            // ---- Last line: sign restrictions ----------------------------------------
            var restrictionLine = lines[^1];

            // ---- Middle lines: constraints --------------------------------------------
            var constraintLines = lines.Skip(1).Take(lines.Count - 2).ToList();
            if (constraintLines.Count == 0)
                throw new ModelInputException("At least one constraint line is required.");

            var constraints = constraintLines.Select(l => ParseConstraintLine(l, varCount)).ToList();

            var restrictions = ParseRestrictionLine(restrictionLine, varCount);

            var model = new LPModel(objSense, objCoefficients, constraints, restrictions);

            ValidateSemantics(model);

            return model;
        }

        private static (ObjectiveSense, List<double>) ParseObjectiveLine((int Number, string Text) line)
        {
            var tokens = Tokenize(line.Text);
            if (tokens.Count < 2)
                throw new ModelInputException(
                    "The objective line must start with 'max' or 'min' followed by at least one signed coefficient.",
                    line.Number);

            string keyword = tokens[0].ToLowerInvariant();
            ObjectiveSense sense = keyword switch
            {
                "max" => ObjectiveSense.Maximize,
                "min" => ObjectiveSense.Minimize,
                _ => throw new ModelInputException(
                        $"Expected 'max' or 'min' as the first word, but found '{tokens[0]}'.", line.Number)
            };

            var coefficients = new List<double>();
            for (int i = 1; i < tokens.Count; i++)
            {
                coefficients.Add(ParseSignedNumber(tokens[i], line.Number, $"objective coefficient #{i}"));
            }

            return (sense, coefficients);
        }

        private static Constraint ParseConstraintLine((int Number, string Text) line, int expectedVarCount)
        {
            var tokens = Tokenize(line.Text);
            if (tokens.Count < 2)
                throw new ModelInputException(
                    "A constraint line needs coefficients followed by a relation and a right-hand-side.",
                    line.Number);

            // The last token holds the relation glued to the RHS, e.g. "<=40"
            string relationToken = tokens[^1];
            var relMatch = RelationRhs.Match(relationToken);
            if (!relMatch.Success)
                throw new ModelInputException(
                    $"Could not parse the relation/right-hand-side '{relationToken}'. " +
                    "Expected a format such as '<=40', '>=10' or '=15'.", line.Number);

            RelationType relation = relMatch.Groups[1].Value switch
            {
                "<=" => RelationType.LessOrEqual,
                ">=" => RelationType.GreaterOrEqual,
                "=" => RelationType.Equal,
                _ => throw new ModelInputException($"Unknown relation operator '{relMatch.Groups[1].Value}'.", line.Number)
            };
            double rhs = double.Parse(relMatch.Groups[2].Value, CultureInfo.InvariantCulture);

            var coefficientTokens = tokens.Take(tokens.Count - 1).ToList();
            if (coefficientTokens.Count != expectedVarCount)
                throw new ModelInputException(
                    $"Expected {expectedVarCount} technological coefficients (one per decision variable defined " +
                    $"on line 1) but found {coefficientTokens.Count}.", line.Number);

            var coefficients = new List<double>();
            for (int i = 0; i < coefficientTokens.Count; i++)
                coefficients.Add(ParseSignedNumber(coefficientTokens[i], line.Number, $"technological coefficient #{i + 1}"));

            return new Constraint(coefficients, relation, rhs);
        }

        private static List<VariableRestriction> ParseRestrictionLine((int Number, string Text) line, int expectedVarCount)
        {
            var tokens = Tokenize(line.Text);
            if (tokens.Count != expectedVarCount)
                throw new ModelInputException(
                    $"Expected {expectedVarCount} sign restrictions (one per decision variable) but found {tokens.Count}.",
                    line.Number);

            var result = new List<VariableRestriction>();
            foreach (var t in tokens)
            {
                if (!RestrictionTokens.Contains(t))
                    throw new ModelInputException(
                        $"'{t}' is not a valid sign restriction. Use one of: +, -, urs, int, bin.", line.Number);

                result.Add(t.ToLowerInvariant() switch
                {
                    "+" => VariableRestriction.Positive,
                    "-" => VariableRestriction.Negative,
                    "urs" => VariableRestriction.Unrestricted,
                    "int" => VariableRestriction.Integer,
                    "bin" => VariableRestriction.Binary,
                    _ => throw new ModelInputException($"Unrecognised restriction token '{t}'.", line.Number)
                });
            }

            return result;
        }

        private static double ParseSignedNumber(string token, int lineNumber, string fieldDescription)
        {
            var m = SignedNumber.Match(token);
            if (!m.Success)
                throw new ModelInputException(
                    $"Could not parse {fieldDescription} '{token}'. Every coefficient must carry an explicit " +
                    "'+' or '-' sign, e.g. '+2' or '-3.5'.", lineNumber);

            double magnitude = double.Parse(m.Groups[2].Value, CultureInfo.InvariantCulture);
            return m.Groups[1].Value == "-" ? -magnitude : magnitude;
        }

        /// <summary>
        /// Splits a line on whitespace and re-joins any lone '+' / '-' token with the
        /// number that follows it, so the parser tolerates files where the sign and
        /// magnitude were typed with a space between them (e.g. "+ 2" instead of "+2").
        /// </summary>
        private static List<string> Tokenize(string line)
        {
            var raw = line.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries);
            var merged = new List<string>();

            for (int i = 0; i < raw.Length; i++)
            {
                if ((raw[i] == "+" || raw[i] == "-") && i + 1 < raw.Length && Regex.IsMatch(raw[i + 1], @"^\d"))
                {
                    merged.Add(raw[i] + raw[i + 1]);
                    i++;
                }
                else
                {
                    merged.Add(raw[i]);
                }
            }

            return merged;
        }

        /// <summary>Cross-field validation that cannot be checked while a single line is being read.</summary>
        private static void ValidateSemantics(LPModel model)
        {
            if (model.VariableCount == 0)
                throw new ModelInputException("The model must define at least one decision variable.");

            foreach (var c in model.Constraints)
            {
                if (c.Coefficients.Count != model.VariableCount)
                    throw new ModelInputException(
                        "Internal consistency error: a constraint does not have the same number of " +
                        "coefficients as decision variables.");
            }

            if (model.SignRestrictions.Count != model.VariableCount)
                throw new ModelInputException(
                    "The number of sign restrictions does not match the number of decision variables.");

            // Binary variables implicitly need an upper bound of 1 - warn only if a
            // matching explicit constraint is missing is NOT an error (it is implied),
            // so no exception is raised here; solvers apply the bound themselves.
        }
    }
}
