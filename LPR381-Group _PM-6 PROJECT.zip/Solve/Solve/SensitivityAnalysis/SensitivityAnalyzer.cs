using System;
using System.Collections.Generic;
using System.Linq;
using Solve.IO;
using Solve.Models;
using Solve.Solvers;

namespace Solve.SensitivityAnalysis
{
    /// <summary>
    /// Post-optimality analysis operations. Everything here works directly off
    /// the final optimal <see cref="SimplexTableau"/> exposed by any
    /// simplex-family solver's <see cref="SolveResult.FinalTableau"/> - Primal
    /// Simplex, Revised Simplex, Cutting Plane, and Branch &amp; Bound Simplex
    /// all expose one (the winning node's tableau, for Branch &amp; Bound),
    /// so every operation below works no matter which algorithm produced the
    /// optimal solution. Only the Knapsack Branch &amp; Bound algorithm does not
    /// go through the simplex tableau at all, so sensitivity analysis is not
    /// available for its results (this is reported clearly, not silently ignored).
    /// </summary>
    public static class SensitivityAnalyzer
    {
        private const double Eps = 1e-9;

        public static bool HasUsableTableau(SolveResult result) =>
            result.Status == SolutionStatus.Optimal && result.FinalTableau is SimplexTableau;

        private static bool TryGetTableau(SolveResult result, ResultLogger log, out SimplexTableau tableau)
        {
            if (HasUsableTableau(result))
            {
                tableau = (SimplexTableau)result.FinalTableau!;
                return true;
            }

            log.WriteLine("This operation requires a completed optimal solve using a simplex-family " +
                          "algorithm (Primal Simplex, Revised Simplex, Cutting Plane, or Branch & Bound " +
                          "Simplex) first - the Knapsack Branch & Bound algorithm does not build a tableau.");
            tableau = null!;
            return false;
        }

        /// <summary>Every column-conversion multiplier for original variable <paramref name="varIndex"/>:
        /// how a change of 1 in the ORIGINAL objective coefficient translates into a change in the
        /// tableau's internal (always-maximised) cost for that variable's column.</summary>
        private static double ObjectiveCostMultiplier(SimplexTableau tableau, int varIndex)
        {
            double senseSign = tableau.OriginalIsMinimization ? -1.0 : 1.0;
            var mapping = tableau.VariableMappings[varIndex];
            return mapping.Kind == MappingKind.Negated ? -senseSign : senseSign;
        }

        /// <summary>How a change of 1 in an ORIGINAL constraint coefficient a_rj translates into a
        /// change in the tableau's internal coefficient for that (variable, row) cell.</summary>
        private static double CoefficientMultiplier(SimplexTableau tableau, int varIndex)
        {
            var mapping = tableau.VariableMappings[varIndex];
            return mapping.Kind == MappingKind.Negated ? -1.0 : 1.0;
        }

        /// <summary>Converts an internal-delta range [deltaLow, deltaHigh] into an ORIGINAL-value
        /// range, given the current original value and the conversion multiplier. Handles both
        /// signs of multiplier and infinities correctly by taking min/max of the two mapped ends.</summary>
        private static (double Lo, double Hi) MapDeltaRangeToOriginal(double currentOriginalValue,
            double deltaLow, double deltaHigh, double multiplier)
        {
            double a = currentOriginalValue + deltaLow / multiplier;
            double b = currentOriginalValue + deltaHigh / multiplier;
            return (Math.Min(a, b), Math.Max(a, b));
        }

        private static string FormatBound(double value) =>
            double.IsNegativeInfinity(value) ? "-infinity" :
            double.IsPositiveInfinity(value) ? "+infinity" :
            ResultLogger.Fmt(value);

        // =====================================================================
        // Variable classification (for populating pickers / validating a choice)
        // =====================================================================

        /// <summary>True if the original variable is currently NON-basic (value 0 at the optimum).
        /// Unrestricted ('urs') variables, which are internally split into two columns, are not
        /// supported by the ranging operations below and are reported as neither.</summary>
        public static bool IsNonBasic(SimplexTableau tableau, int varIndex)
        {
            var mapping = tableau.VariableMappings[varIndex];
            if (mapping.Kind == MappingKind.Split) return false;
            return tableau.BasicRowOfColumn(mapping.ColumnIndex) == -1;
        }

        public static bool IsBasic(SimplexTableau tableau, int varIndex)
        {
            var mapping = tableau.VariableMappings[varIndex];
            if (mapping.Kind == MappingKind.Split) return false;
            return tableau.BasicRowOfColumn(mapping.ColumnIndex) != -1;
        }

        public static List<int> GetNonBasicVariableIndices(LPModel model, SolveResult result)
        {
            var indices = new List<int>();
            if (!(result.FinalTableau is SimplexTableau tableau)) return indices;
            for (int index = 0; index < model.VariableCount; index++)
                if (IsNonBasic(tableau, index)) indices.Add(index);
            return indices;
        }

        public static List<int> GetBasicVariableIndices(LPModel model, SolveResult result)
        {
            var indices = new List<int>();
            if (!(result.FinalTableau is SimplexTableau tableau)) return indices;
            for (int index = 0; index < model.VariableCount; index++)
                if (IsBasic(tableau, index)) indices.Add(index);
            return indices;
        }

        // =====================================================================
        // 1/2. Non-Basic Variable: range + apply
        // =====================================================================

        public static void RangeNonBasicVariable(LPModel model, SolveResult result, int varIndex, ResultLogger log)
        {
            log.WriteHeading($"Range of Non-Basic Variable: {model.VariableNames[varIndex]}");
            if (!TryGetTableau(result, log, out var tableau)) return;

            var mapping = tableau.VariableMappings[varIndex];
            if (mapping.Kind == MappingKind.Split)
            {
                log.WriteLine("Ranging is not supported for unrestricted ('urs') variables in this build.");
                return;
            }
            if (!IsNonBasic(tableau, varIndex))
            {
                log.WriteLine($"{model.VariableNames[varIndex]} is currently BASIC, not non-basic. " +
                              "Use 'Range of a Basic Variable' instead.");
                return;
            }

            double reducedCost = tableau.ReducedCost(mapping.ColumnIndex);
            double multiplier = ObjectiveCostMultiplier(tableau, varIndex);
            var (lo, hi) = MapDeltaRangeToOriginal(model.ObjectiveCoefficients[varIndex],
                double.NegativeInfinity, reducedCost, multiplier);

            log.WriteLine($"Current objective coefficient: {ResultLogger.Fmt(model.ObjectiveCoefficients[varIndex])}");
            log.WriteLine($"Allowable range (keeps the current basis optimal): [{FormatBound(lo)}, {FormatBound(hi)}]");
            log.WriteLine("Outside this range the current basis is no longer optimal and the model must be re-solved.");
        }

        /// <summary>Applies a new objective coefficient to a non-basic variable. Returns a freshly
        /// re-solved <see cref="SolveResult"/> if the change fell outside the allowable range and a
        /// re-solve was required, or null if the current optimal solution/basis remains valid unchanged.</summary>
        public static SolveResult? ApplyNonBasicVariableChange(LPModel model, SolveResult result, int varIndex,
            double newCoefficient, ResultLogger log)
        {
            log.WriteHeading($"Apply Change - Non-Basic Variable: {model.VariableNames[varIndex]}");
            if (!TryGetTableau(result, log, out var tableau)) return null;

            var mapping = tableau.VariableMappings[varIndex];
            if (mapping.Kind == MappingKind.Split)
            {
                log.WriteLine("Applying changes is not supported for unrestricted ('urs') variables in this build.");
                return null;
            }
            if (!IsNonBasic(tableau, varIndex))
            {
                log.WriteLine($"{model.VariableNames[varIndex]} is currently BASIC, not non-basic. " +
                              "Use 'Apply Change - Basic Variable' instead.");
                return null;
            }

            double reducedCost = tableau.ReducedCost(mapping.ColumnIndex);
            double multiplier = ObjectiveCostMultiplier(tableau, varIndex);
            var (lo, hi) = MapDeltaRangeToOriginal(model.ObjectiveCoefficients[varIndex],
                double.NegativeInfinity, reducedCost, multiplier);

            log.WriteLine($"New objective coefficient: {ResultLogger.Fmt(newCoefficient)}  (allowable range: [{FormatBound(lo)}, {FormatBound(hi)}])");

            if (newCoefficient >= lo - 1e-6 && newCoefficient <= hi + 1e-6)
            {
                log.WriteLine("Within the allowable range - the current basis remains optimal.");
                log.WriteLine($"{model.VariableNames[varIndex]} stays non-basic (value 0); the optimal solution and objective value are unchanged.");
                return null;
            }

            log.WriteLine("Outside the allowable range - the current basis is no longer guaranteed optimal. Re-solving from scratch...");
            var newModel = model.Clone();
            newModel.ObjectiveCoefficients[varIndex] = newCoefficient;
            return new PrimalSimplexSolver().Solve(newModel, log);
        }

        // =====================================================================
        // 3/4. Basic Variable: range + apply
        // =====================================================================

        /// <summary>Computes the allowable internal-delta range [lo, hi] for the cost of the basic
        /// variable currently occupying tableau row <paramref name="row"/> (1-based Data row index).</summary>
        private static (double Lo, double Hi) BasicCostDeltaRange(SimplexTableau tableau, int row)
        {
            var basisColumns = new HashSet<int>(tableau.BasicColumnOfRow);
            double lower = double.NegativeInfinity, upper = double.PositiveInfinity;

            for (int column = 0; column < tableau.RhsIndex; column++)
            {
                if (basisColumns.Contains(column)) continue;
                double coefficientInRow = tableau.Data[row, column];
                if (Math.Abs(coefficientInRow) < Eps) continue;

                double reducedCostHere = tableau.Data[0, column];
                double bound = -reducedCostHere / coefficientInRow;
                if (coefficientInRow > 0) lower = Math.Max(lower, bound);
                else upper = Math.Min(upper, bound);
            }

            return (lower, upper);
        }

        public static void RangeBasicVariable(LPModel model, SolveResult result, int varIndex, ResultLogger log)
        {
            log.WriteHeading($"Range of Basic Variable: {model.VariableNames[varIndex]}");
            if (!TryGetTableau(result, log, out var tableau)) return;

            var mapping = tableau.VariableMappings[varIndex];
            if (mapping.Kind == MappingKind.Split)
            {
                log.WriteLine("Ranging is not supported for unrestricted ('urs') variables in this build.");
                return;
            }
            int row = tableau.BasicRowOfColumn(mapping.ColumnIndex);
            if (row == -1)
            {
                log.WriteLine($"{model.VariableNames[varIndex]} is currently NON-BASIC, not basic. " +
                              "Use 'Range of a Non-Basic Variable' instead.");
                return;
            }

            var (deltaLow, deltaHigh) = BasicCostDeltaRange(tableau, row);
            double multiplier = ObjectiveCostMultiplier(tableau, varIndex);
            var (lo, hi) = MapDeltaRangeToOriginal(model.ObjectiveCoefficients[varIndex], deltaLow, deltaHigh, multiplier);

            log.WriteLine($"Current objective coefficient: {ResultLogger.Fmt(model.ObjectiveCoefficients[varIndex])}");
            log.WriteLine($"Allowable range (keeps the current basis optimal): [{FormatBound(lo)}, {FormatBound(hi)}]");
            log.WriteLine("Within this range the solution (which variables are basic, and their values) stays the same; only the objective value changes.");
        }

        public static SolveResult? ApplyBasicVariableChange(LPModel model, SolveResult result, int varIndex,
            double newCoefficient, ResultLogger log)
        {
            log.WriteHeading($"Apply Change - Basic Variable: {model.VariableNames[varIndex]}");
            if (!TryGetTableau(result, log, out var tableau)) return null;

            var mapping = tableau.VariableMappings[varIndex];
            if (mapping.Kind == MappingKind.Split)
            {
                log.WriteLine("Applying changes is not supported for unrestricted ('urs') variables in this build.");
                return null;
            }
            int row = tableau.BasicRowOfColumn(mapping.ColumnIndex);
            if (row == -1)
            {
                log.WriteLine($"{model.VariableNames[varIndex]} is currently NON-BASIC, not basic. " +
                              "Use 'Apply Change - Non-Basic Variable' instead.");
                return null;
            }

            var (deltaLow, deltaHigh) = BasicCostDeltaRange(tableau, row);
            double multiplier = ObjectiveCostMultiplier(tableau, varIndex);
            var (lo, hi) = MapDeltaRangeToOriginal(model.ObjectiveCoefficients[varIndex], deltaLow, deltaHigh, multiplier);

            log.WriteLine($"New objective coefficient: {ResultLogger.Fmt(newCoefficient)}  (allowable range: [{FormatBound(lo)}, {FormatBound(hi)}])");

            if (newCoefficient >= lo - 1e-6 && newCoefficient <= hi + 1e-6)
            {
                double deltaOriginal = newCoefficient - model.ObjectiveCoefficients[varIndex];
                double deltaInternal = deltaOriginal * multiplier;
                double basicValue = tableau.Data[row, tableau.RhsIndex];
                double newInternalObjective = tableau.Data[0, tableau.RhsIndex] + deltaInternal * basicValue;
                double newObjective = tableau.ToOriginalObjective(newInternalObjective);

                log.WriteLine("Within the allowable range - the current basis (and every variable's value) remains optimal and unchanged.");
                log.WriteLine($"New objective value: {ResultLogger.Fmt(newObjective)} (was {ResultLogger.Fmt(result.ObjectiveValue)}).");
                return null;
            }

            log.WriteLine("Outside the allowable range - the current basis is no longer guaranteed optimal. Re-solving from scratch...");
            var newModel = model.Clone();
            newModel.ObjectiveCoefficients[varIndex] = newCoefficient;
            return new PrimalSimplexSolver().Solve(newModel, log);
        }

        // =====================================================================
        // 5/6. Constraint RHS: range + apply
        // =====================================================================

        public static void RangeConstraintRhs(LPModel model, SolveResult result, int constraintIndex, ResultLogger log)
        {
            log.WriteHeading($"Range of RHS: Constraint {constraintIndex + 1}");
            if (!TryGetTableau(result, log, out var tableau)) return;

            double[] basisInverseColumn = tableau.GetBasisInverseColumnByRow(constraintIndex);
            double lower = double.NegativeInfinity, upper = double.PositiveInfinity;

            for (int row = 0; row < tableau.Rows - 1; row++)
            {
                double coefficient = basisInverseColumn[row];
                if (Math.Abs(coefficient) < Eps) continue;
                double currentBasicValue = tableau.Data[row + 1, tableau.RhsIndex];
                double bound = -currentBasicValue / coefficient;
                if (coefficient > 0) lower = Math.Max(lower, bound);
                else upper = Math.Min(upper, bound);
            }

            double currentRhs = model.Constraints[constraintIndex].Rhs;
            double lo = currentRhs + lower, hi = currentRhs + upper;

            log.WriteLine($"Current right-hand-side: {ResultLogger.Fmt(currentRhs)}");
            log.WriteLine($"Allowable range (keeps the current basis feasible): [{FormatBound(lo)}, {FormatBound(hi)}]");
            log.WriteLine("Within this range the same variables stay basic; only their values (and the objective) change.");
        }

        public static SolveResult? ApplyConstraintRhsChange(LPModel model, SolveResult result, int constraintIndex,
            double newRhs, ResultLogger log)
        {
            log.WriteHeading($"Apply Change - RHS: Constraint {constraintIndex + 1}");
            if (!TryGetTableau(result, log, out var tableau)) return null;

            double[] basisInverseColumn = tableau.GetBasisInverseColumnByRow(constraintIndex);
            double lower = double.NegativeInfinity, upper = double.PositiveInfinity;
            for (int row = 0; row < tableau.Rows - 1; row++)
            {
                double coefficient = basisInverseColumn[row];
                if (Math.Abs(coefficient) < Eps) continue;
                double currentBasicValue = tableau.Data[row + 1, tableau.RhsIndex];
                double bound = -currentBasicValue / coefficient;
                if (coefficient > 0) lower = Math.Max(lower, bound);
                else upper = Math.Min(upper, bound);
            }

            double currentRhs = model.Constraints[constraintIndex].Rhs;
            double lo = currentRhs + lower, hi = currentRhs + upper;
            log.WriteLine($"New right-hand-side: {ResultLogger.Fmt(newRhs)}  (allowable range: [{FormatBound(lo)}, {FormatBound(hi)}])");

            if (newRhs >= lo - 1e-6 && newRhs <= hi + 1e-6)
            {
                double delta = newRhs - currentRhs;
                var columnValues = tableau.GetColumnValues();
                for (int row = 0; row < tableau.Rows - 1; row++)
                {
                    int basicColumn = tableau.BasicColumnOfRow[row];
                    columnValues[basicColumn] = tableau.Data[row + 1, tableau.RhsIndex] + delta * basisInverseColumn[row];
                }
                var newValues = tableau.RecoverVariableValues(columnValues);
                double shadowPrice = tableau.ToOriginalObjective(tableau.GetShadowPriceInternal(constraintIndex));
                double newObjective = result.ObjectiveValue + delta * shadowPrice;

                log.WriteLine("Within the allowable range - the current basis remains optimal.");
                for (int i = 0; i < newValues.Length; i++)
                    log.WriteLine($"  {model.VariableNames[i]} = {ResultLogger.Fmt(newValues[i])}");
                log.WriteLine($"New objective value: {ResultLogger.Fmt(newObjective)} (was {ResultLogger.Fmt(result.ObjectiveValue)}).");
                return null;
            }

            log.WriteLine("Outside the allowable range - the current basis is no longer guaranteed feasible. Re-solving from scratch...");
            var newModel = model.Clone();
            newModel.Constraints[constraintIndex].Rhs = newRhs;
            return new PrimalSimplexSolver().Solve(newModel, log);
        }

        // =====================================================================
        // 7/8. Coefficient inside a Non-Basic column: range + apply
        // =====================================================================

        public static void RangeNonBasicColumnCoefficient(LPModel model, SolveResult result, int varIndex,
            int constraintIndex, ResultLogger log)
        {
            log.WriteHeading($"Range of a_{{{constraintIndex + 1},{varIndex + 1}}} (constraint {constraintIndex + 1}, variable {model.VariableNames[varIndex]})");
            if (!TryGetTableau(result, log, out var tableau)) return;

            var mapping = tableau.VariableMappings[varIndex];
            if (mapping.Kind == MappingKind.Split)
            {
                log.WriteLine("Ranging is not supported for unrestricted ('urs') variables in this build.");
                return;
            }
            if (!IsNonBasic(tableau, varIndex))
            {
                log.WriteLine($"{model.VariableNames[varIndex]} is currently BASIC. This operation only applies to a coefficient inside a NON-basic variable's column.");
                return;
            }

            double reducedCost = tableau.ReducedCost(mapping.ColumnIndex);
            double shadowPriceInternal = tableau.GetShadowPriceInternal(constraintIndex);
            double lower = double.NegativeInfinity, upper = double.PositiveInfinity;
            if (Math.Abs(shadowPriceInternal) > Eps)
            {
                double bound = reducedCost / shadowPriceInternal;
                if (shadowPriceInternal > 0) upper = bound; else lower = bound;
            }

            double coefficientMultiplier = CoefficientMultiplier(tableau, varIndex);
            double currentCoefficient = model.Constraints[constraintIndex].Coefficients[varIndex];
            var (lo, hi) = MapDeltaRangeToOriginal(currentCoefficient, lower, upper, coefficientMultiplier);

            log.WriteLine($"Current coefficient: {ResultLogger.Fmt(currentCoefficient)}");
            log.WriteLine($"Allowable range (keeps the current basis optimal): [{FormatBound(lo)}, {FormatBound(hi)}]");
        }

        public static SolveResult? ApplyNonBasicColumnCoefficientChange(LPModel model, SolveResult result,
            int varIndex, int constraintIndex, double newCoefficient, ResultLogger log)
        {
            log.WriteHeading($"Apply Change - a_{{{constraintIndex + 1},{varIndex + 1}}} (constraint {constraintIndex + 1}, variable {model.VariableNames[varIndex]})");
            if (!TryGetTableau(result, log, out var tableau)) return null;

            var mapping = tableau.VariableMappings[varIndex];
            if (mapping.Kind == MappingKind.Split)
            {
                log.WriteLine("Applying changes is not supported for unrestricted ('urs') variables in this build.");
                return null;
            }
            if (!IsNonBasic(tableau, varIndex))
            {
                log.WriteLine($"{model.VariableNames[varIndex]} is currently BASIC. This operation only applies to a coefficient inside a NON-basic variable's column.");
                return null;
            }

            double reducedCost = tableau.ReducedCost(mapping.ColumnIndex);
            double shadowPriceInternal = tableau.GetShadowPriceInternal(constraintIndex);
            double lower = double.NegativeInfinity, upper = double.PositiveInfinity;
            if (Math.Abs(shadowPriceInternal) > Eps)
            {
                double bound = reducedCost / shadowPriceInternal;
                if (shadowPriceInternal > 0) upper = bound; else lower = bound;
            }

            double coefficientMultiplier = CoefficientMultiplier(tableau, varIndex);
            double currentCoefficient = model.Constraints[constraintIndex].Coefficients[varIndex];
            var (lo, hi) = MapDeltaRangeToOriginal(currentCoefficient, lower, upper, coefficientMultiplier);

            log.WriteLine($"New coefficient: {ResultLogger.Fmt(newCoefficient)}  (allowable range: [{FormatBound(lo)}, {FormatBound(hi)}])");

            if (newCoefficient >= lo - 1e-6 && newCoefficient <= hi + 1e-6)
            {
                log.WriteLine("Within the allowable range - the current basis remains optimal.");
                log.WriteLine($"{model.VariableNames[varIndex]} stays non-basic (value 0); the optimal solution and objective value are unchanged.");
                return null;
            }

            log.WriteLine("Outside the allowable range - the current basis is no longer guaranteed optimal. Re-solving from scratch...");
            var newModel = model.Clone();
            newModel.Constraints[constraintIndex].Coefficients[varIndex] = newCoefficient;
            return new PrimalSimplexSolver().Solve(newModel, log);
        }

        // =====================================================================
        // 9. Add a new activity (variable) to the optimal solution
        // =====================================================================

        public static SolveResult AddNewActivity(LPModel model, SolveResult result, double objectiveCoefficient,
            double[] constraintCoefficients, VariableRestriction restriction, ResultLogger log)
        {
            log.WriteHeading("Add a New Activity");

            if (TryGetTableau(result, log, out var tableau))
            {
                double senseSign = tableau.OriginalIsMinimization ? -1.0 : 1.0;
                double internalCost = senseSign * objectiveCoefficient;
                double internalZ = 0;
                for (int constraintIndex = 0; constraintIndex < model.Constraints.Count; constraintIndex++)
                    internalZ += constraintCoefficients[constraintIndex] * tableau.GetShadowPriceInternal(constraintIndex);
                double impliedReducedCost = internalZ - internalCost;

                log.WriteLine($"Reduced cost of the new activity under the current optimal basis: {ResultLogger.Fmt(impliedReducedCost)}");
                log.WriteLine(impliedReducedCost >= -Eps
                    ? "This is >= 0: the current optimal solution would remain optimal even with this activity available (it just wouldn't be used)."
                    : "This is < 0: bringing this activity in would improve the objective - the model needs to be re-solved.");
            }
            else
            {
                log.WriteLine("(Skipping the reduced-cost preview since no tableau is available - re-solving directly.)");
            }

            var newModel = model.Clone();
            newModel.ObjectiveCoefficients.Add(objectiveCoefficient);
            string newName = $"x{newModel.ObjectiveCoefficients.Count}";
            newModel.VariableNames.Add(newName);
            newModel.SignRestrictions.Add(restriction);
            for (int constraintIndex = 0; constraintIndex < newModel.Constraints.Count; constraintIndex++)
                newModel.Constraints[constraintIndex].Coefficients.Add(constraintCoefficients[constraintIndex]);

            log.WriteSubHeading("Re-solving with the new activity included");
            log.WriteLine(newModel.ToDisplayString());

            bool needsIntegerSolver = newModel.HasIntegerRestrictions;
            ISolver solver = needsIntegerSolver ? new CuttingPlaneSolver() : new PrimalSimplexSolver();
            return solver.Solve(newModel, log);
        }

        // =====================================================================
        // 10. Add a new constraint to the optimal solution
        // =====================================================================

        public static SolveResult AddNewConstraint(LPModel model, SolveResult result, double[] coefficients,
            RelationType relation, double rhs, ResultLogger log)
        {
            log.WriteHeading("Add a New Constraint");

            double lhsValue = 0;
            for (int varIndex = 0; varIndex < model.VariableCount; varIndex++)
                lhsValue += coefficients[varIndex] * result.VariableValues[varIndex];

            bool satisfied = relation switch
            {
                RelationType.LessOrEqual => lhsValue <= rhs + 1e-6,
                RelationType.GreaterOrEqual => lhsValue >= rhs - 1e-6,
                RelationType.Equal => Math.Abs(lhsValue - rhs) <= 1e-6,
                _ => false
            };

            string relationSymbol = relation switch
            {
                RelationType.LessOrEqual => "<=",
                RelationType.GreaterOrEqual => ">=",
                _ => "="
            };
            log.WriteLine($"Current optimal solution gives a left-hand-side value of {ResultLogger.Fmt(lhsValue)} " +
                          $"for this constraint ({relationSymbol} {ResultLogger.Fmt(rhs)}).");

            var newModel = model.Clone();
            newModel.Constraints.Add(new Constraint(coefficients.ToList(), relation, rhs));

            if (satisfied)
            {
                log.WriteLine("The current optimal solution already satisfies this constraint - it remains optimal and unchanged.");
                return result;
            }

            log.WriteLine("The current optimal solution VIOLATES this constraint - re-solving with it included...");
            log.WriteSubHeading("Re-solving with the new constraint included");
            log.WriteLine(newModel.ToDisplayString());

            bool needsIntegerSolver = newModel.HasIntegerRestrictions;
            ISolver solver = needsIntegerSolver ? new CuttingPlaneSolver() : new PrimalSimplexSolver();
            return solver.Solve(newModel, log);
        }

        // =====================================================================
        // 11. Shadow prices
        // =====================================================================

        public static void DisplayShadowPrices(LPModel model, SolveResult result, ResultLogger log)
        {
            log.WriteHeading("Shadow Prices");
            if (!TryGetTableau(result, log, out var tableau)) return;

            for (int constraintIndex = 0; constraintIndex < model.Constraints.Count; constraintIndex++)
            {
                double internalShadowPrice = tableau.GetShadowPriceInternal(constraintIndex);
                double shadowPrice = tableau.ToOriginalObjective(internalShadowPrice);
                var constraint = model.Constraints[constraintIndex];
                log.WriteLine($"  Constraint {constraintIndex + 1} ({constraint.RelationSymbol} {ResultLogger.Fmt(constraint.Rhs)}): " +
                              $"shadow price = {ResultLogger.Fmt(shadowPrice)}");
            }
        }

        // =====================================================================
        // 12. Duality
        // =====================================================================

        public static LPModel DisplayDual(LPModel primal, ResultLogger log)
        {
            log.WriteHeading("Duality");
            log.WriteSubHeading("Primal Model");
            log.WriteLine(primal.ToDisplayString());

            var dualSense = primal.Sense == ObjectiveSense.Maximize ? ObjectiveSense.Minimize : ObjectiveSense.Maximize;
            var dualObjective = primal.Constraints.Select(constraint => constraint.Rhs).ToList();

            var dualConstraints = new List<Constraint>();
            for (int varIndex = 0; varIndex < primal.VariableCount; varIndex++)
            {
                var columnCoefficients = primal.Constraints.Select(constraint => constraint.Coefficients[varIndex]).ToList();
                var dualRelation = primal.Sense == ObjectiveSense.Maximize ? RelationType.GreaterOrEqual : RelationType.LessOrEqual;
                dualConstraints.Add(new Constraint(columnCoefficients, dualRelation, primal.ObjectiveCoefficients[varIndex]));
            }

            var dualRestrictions = Enumerable.Repeat(VariableRestriction.Positive, primal.Constraints.Count).ToList();
            var dual = new LPModel(dualSense, dualObjective, dualConstraints, dualRestrictions);

            log.WriteSubHeading("Dual Model");
            log.WriteLine(dual.ToDisplayString());

            return dual;
        }

        public static void SolveDualAndCheckDuality(LPModel primal, SolveResult primalResult, ResultLogger log)
        {
            var dual = DisplayDual(primal, log);

            var dualSolver = new PrimalSimplexSolver();
            var dualResult = dualSolver.Solve(dual, log);

            log.WriteSubHeading("Strong / Weak Duality Check");
            if (primalResult.Status == SolutionStatus.Optimal && dualResult.Status == SolutionStatus.Optimal)
            {
                bool strong = Math.Abs(primalResult.ObjectiveValue - dualResult.ObjectiveValue) < 1e-4;
                log.WriteLine($"  Primal objective = {ResultLogger.Fmt(primalResult.ObjectiveValue)}, Dual objective = {ResultLogger.Fmt(dualResult.ObjectiveValue)}");
                log.WriteLine(strong
                    ? "  STRONG DUALITY holds: the primal and dual optimal objective values are equal."
                    : "  WEAK DUALITY only: the primal and dual optimal objective values differ (unexpected for a correctly-formed LP - check the model).");
            }
            else
            {
                log.WriteLine("  Duality could not be fully verified because the primal and/or dual did not reach an optimal solution.");
                log.WriteLine("  (Weak duality still guarantees the dual objective bounds the primal objective whenever both are feasible.)");
            }
        }
    }
}
