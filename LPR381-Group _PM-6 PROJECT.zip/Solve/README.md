# Solve — Linear & Integer Programming Solver

A .NET 8 **WPF desktop application** (builds to **solve.exe**) that parses a
Linear/Integer Programming model from a text file, solves it with a chosen
algorithm, and performs post-optimality (sensitivity) analysis — through a
proper Windows app UI (sidebar navigation, cards, a live results panel and a
scrolling log) rather than a plain console prompt. It is still fully
"menu driven" as the brief requires, just via clickable menu items instead of
typed numbers. Written in C# as a standard Visual Studio solution.

> **Windows only.** WPF is a Windows UI framework, so this project targets
> `net8.0-windows` and must be built/run on Windows (in Visual Studio, or via
> `dotnet run` on a Windows machine). If you need to demo on macOS/Linux, the
> previous console-only build is available on request as a fallback.

This build's area of focus, as requested, is: **the Cutting Plane Algorithm,
error handling, the console interface, the overall project outline, and
input/output file integration.** All five solving algorithms (Primal Simplex,
Revised Primal Simplex, Branch & Bound Simplex, Cutting Plane, Branch & Bound
Knapsack) are now fully implemented and working end-to-end.

## Opening the project

1. Open **Solve.sln** in Visual Studio 2022 (or later) **on Windows**, with
   the ".NET desktop development" workload installed (this brings in the WPF
   designer/build tooling). `dotnet build`/`dotnet run` from a Windows command
   line also work.
2. Set **Solve** as the startup project (already the only project in the
   solution) and press **Start** / **F5**, or run:
   ```
   dotnet run --project Solve
   ```
3. A Release build produces `solve.exe` (plus its .dll) in
   `Solve/bin/Release/net8.0-windows/`.

> Note: this sandbox that authored the code does not have Windows or the
> WPF/.NET SDK tooling installed, so the project could not be compiled/run
> here. It was written and reviewed carefully by hand against the C# language,
> .NET BCL and WPF/XAML conventions, but please do a first build in Visual
> Studio before a live demo, and let me know if the compiler flags anything
> so it can be fixed immediately.

## Using the app

- **Dashboard** — at-a-glance summary of the currently loaded model, plus
  quick actions to load a file or try the bundled Knapsack example instantly.
- **Load Model** — browse to (or type) an input file path, load it, and see
  the parsed model echoed back for confirmation before you solve anything.
- **Solve** — pick an algorithm from the card list; it runs on a background
  thread while the right-hand panel streams every tableau iteration live and
  updates the objective value / variable table the moment it's optimal.
- **Sensitivity Analysis** — available once a model has been solved to
  optimality; Shadow Prices and Duality are fully working, the rest are
  clearly marked placeholders (see below).
- **Settings** — change where results are exported (default `output.txt`,
  same folder as the executable unless you browse elsewhere).

Every solve and every sensitivity action still appends its full transcript
(canonical form, every iteration, rounded to 3 decimals) to the output text
file, exactly as before — the GUI is a new front end over the same
input/output pipeline, not a replacement for it.

## Project layout

```
Solve.sln
Solve/
  App.xaml / App.xaml.cs         WPF application bootstrap + global style/colour resources
  Models/                        Plain data model of an LP/IP (no algorithm logic)
    Enums.cs
    Constraint.cs
    LPModel.cs
    SolveResult.cs
  IO/                             Input parsing & output writing
    ModelInputException.cs        Custom exception with line-number context
    InputParser.cs                Reads & validates the input text file grammar (file or in-memory text)
    ResultLogger.cs                Streams output to: console (optional) + in-memory buffer + a
                                    LineWritten event (used by the GUI's live log), 3-dp rounding
  Solvers/                        One class per algorithm, all behind ISolver
    ISolver.cs
    SimplexTableau.cs              Shared Big-M Primal Simplex + Dual Simplex engine
    ModelPreparation.cs            Expands implicit bounds (e.g. bin => x<=1) into an LP relaxation
    PrimalSimplexSolver.cs         COMPLETE
    CuttingPlaneSolver.cs          COMPLETE
    RevisedSimplexSolver.cs        COMPLETE - genuine Product Form of the Inverse + Price-Out, not a relabelled Primal Simplex
    BranchAndBoundSolver.cs        COMPLETE - LP-relaxation-based B&B with fathoming + backtracking
    KnapsackBranchAndBoundSolver.cs COMPLETE - classic ratio-sorted 0/1 knapsack B&B
  SensitivityAnalysis/
    SensitivityAnalyzer.cs         COMPLETE - all 12 operations from the brief
  UI/
    MainWindow.xaml / .xaml.cs     The desktop app shell: sidebar nav, Dashboard/Load/Solve/
                                    Sensitivity/Settings panels, live log + result summary panel
    PromptDialog.cs                 Small code-only (no .xaml) input dialog used by sensitivity operations
Examples/
  knapsack.txt                     The worked Knapsack IP example from the brief
  simple_lp.txt                    A plain LP (no integer restrictions)
  infeasible_lp.txt                Demonstrates infeasibility detection
  unbounded_lp.txt                 Demonstrates unboundedness detection
```

## Input file format

See `Examples/knapsack.txt` for the worked example from the brief:

```
max +2 +3 +3 +5 +2 +4
+11 +8 +6 +14 +10 +10 <=40
bin bin bin bin bin bin
```

* Line 1: `max`/`min`, then one signed coefficient per decision variable.
* One line per constraint: one signed technological coefficient per decision
  variable (same order as line 1), then a relation glued to its RHS
  (`<=40`, `>=10`, `=15`).
* Last line: one sign restriction per decision variable — `+`, `-`, `urs`,
  `int`, or `bin`.

The parser (`IO/InputParser.cs`) accepts **any number of decision variables
and any number of constraints** — there is nothing hard-coded about the
Knapsack example's size. It validates every line and raises a
`ModelInputException` naming the exact line and problem the moment something
doesn't match the grammar (wrong token count, bad number, unknown relation,
unknown restriction keyword, missing file, etc.), so a malformed file never
crashes the program — the menu reports the problem and lets the user try again.

## Error handling

Error handling is threaded through every layer, not bolted on at the end:

* `InputParser` never throws a raw `FormatException`/`IndexOutOfRange` —
  every failure path is translated into a `ModelInputException` with a clear,
  line-numbered message.
* `SimplexTableau.RunPrimalSimplex` explicitly detects and reports
  **unboundedness** (a column can rise forever with no ratio-test candidate)
  and, after optimality, **infeasibility** (an artificial variable is stuck
  in the basis at a positive value) rather than returning a nonsense answer.
* `CuttingPlaneSolver` propagates the relaxation's infeasible/unbounded
  status straight through, and separately detects the case where a Gomory
  cut proves the *integer* model has no feasible solution even though its LP
  relaxation does.
* Every button handler in `MainWindow.xaml.cs` wraps its work in its own
  `try/catch` (`ModelInputException`, `IOException`, then a generic
  fallback) and reports the problem inline (a red status banner on the Load
  screen, an `[ERROR]` line in the live log, or a message box) — the app
  never crashes outright, and the user is always left on a usable screen.
* Numeric solves use an epsilon tolerance and Bland's anti-cycling rule
  (smallest-index entering/leaving variable) so the simplex/dual-simplex
  loops are guaranteed to terminate, plus a hard iteration cap as a final
  safety net.

## The Cutting Plane Algorithm (`Solvers/CuttingPlaneSolver.cs`)

1. Builds the LP relaxation (`ModelPreparation.BuildLpRelaxation`, which turns
   every `bin` variable into a plain non-negative variable with an explicit
   `x <= 1` constraint appended) and solves it with the Big-M Primal Simplex
   method, printing the **Canonical Form** and **every tableau iteration**.
2. If any `int`/`bin` variable's current tableau value is fractional, picks
   the fractional row whose fractional part is closest to 0.5 (a standard
   "most fractional" branching heuristic), and derives a **Gomory fractional
   cut** from it:  `- Σ frac(a_ij)·x_j + e = -frac(RHS_i)`.
3. Appends the cut as a new row/column, prints the resulting (primal
   infeasible) tableau, then restores optimality with the **Dual Simplex
   Algorithm**, printing every dual-simplex iteration too.
4. Repeats from step 2 until every integer-restricted variable is integral
   (optimal integer solution found), a cut proves the model infeasible, or a
   safety cap on the number of cuts is hit.

Try it on `Examples/knapsack.txt` from the "Solve model" menu.

## The other three algorithms

**Revised Primal Simplex (`Solvers/RevisedSimplexSolver.cs`)** — a genuine
revised-simplex implementation, not a relabelled call into Primal Simplex.
It keeps only the current basis inverse `B⁻¹` (starting as the identity,
since the initial slack/artificial basis columns form an identity submatrix)
and prices every candidate column through it on demand, rather than updating
a full tableau. Each iteration logs two distinct steps: **Price-Out**
(the simplex multipliers `y = c_B^T · B⁻¹` and the resulting reduced cost of
every non-basic column) and **Product Form** (the updated `B⁻¹`, obtained via
a single eta/elimination pass rather than recomputing an inverse from
scratch — this is what "Product Form of the Inverse" refers to).

**Branch & Bound Simplex (`Solvers/BranchAndBoundSolver.cs`)** — a
stack-based depth-first search. Each sub-problem's LP relaxation is solved
with the same `SimplexTableau` engine used by Primal Simplex/Cutting Plane
(full canonical form + every tableau iteration logged per node). Nodes are
fathomed for one of three reasons (infeasible/unbounded relaxation, bound
dominated by the current best candidate, or already integral), and branching
adds a `x ≤ floor(v)` / `x ≥ ceil(v)` constraint pair to a cloned model. The
stack naturally backtracks once a branch is exhausted, and the best
candidate across the whole tree is reported at the end.

**Branch & Bound Knapsack (`Solvers/KnapsackBranchAndBoundSolver.cs`)** —
deliberately a *different* algorithm from Branch & Bound Simplex rather than
the same logic restricted to one constraint: it only applies to a
single-constraint, maximising, all-`bin` model, sorts items by value/weight
ratio, and bounds each node with the classic fractional-knapsack relaxation
(fill remaining capacity with whole items in ratio order, then take a
fractional slice of the first item that doesn't fully fit) instead of
calling the simplex engine at all. Also a stack-based DFS with the same
three fathoming reasons (infeasible, bound, complete assignment).

## Output file

Every solve and every sensitivity-analysis action writes through the same
`ResultLogger`, which:
* echoes everything to the console as it happens, and
* appends the full transcript (canonical form, every iteration, the final
  result) to the configured output text file (`output.txt` by default,
  changeable from the main menu), with every decimal value rounded to 3
  places as required.

## Sensitivity Analysis

`SensitivityAnalysis/SensitivityAnalyzer.cs` implements **all twelve**
operations from the brief, working directly off the final optimal
`SimplexTableau` any simplex-family solver exposes (Primal Simplex, Revised
Simplex, Cutting Plane, or the winning node of Branch & Bound Simplex - the
Knapsack Branch & Bound algorithm doesn't build a tableau, so sensitivity
analysis correctly reports it's unavailable for that one):

- **Range / Apply Change - Non-Basic Variable**: how far a non-basic
  variable's objective coefficient can move before its reduced cost would
  turn negative (i.e. before the current basis stops being optimal).
- **Range / Apply Change - Basic Variable**: how far a basic variable's
  objective coefficient can move, derived from how that change ripples
  through every non-basic column's reduced cost via the pivot row.
- **Range / Apply Change - Constraint RHS**: reads `B⁻¹`'s relevant column
  straight off the finished tableau (the slack/artificial column that started
  as the identity vector for that row always still equals `B⁻¹` times that
  original unit vector, however much pivoting has happened since) to find how
  far a right-hand-side can move while every basic variable stays ≥ 0.
- **Range / Apply Change - Non-Basic Column Coefficient**: ranges one
  technological coefficient `a_rj` inside a chosen non-basic variable's
  column, using the same `B⁻¹` column together with that constraint's shadow price.
- **Add a New Activity**: previews the new column's reduced cost under the
  current basis (would it actually help?), then adds it to the model and
  re-solves (via Cutting Plane if the model has integer/binary variables).
- **Add a New Constraint**: checks whether the current optimal solution
  already satisfies it; if so nothing changes, otherwise adds it and re-solves.
- **Shadow Prices** and **Duality** (build the dual model, solve it, and
  report strong/weak duality) as before.

All twelve operations are reachable from the Sensitivity Analysis screen;
the ones that need a variable, constraint, or new value pop up a small input
dialog (`UI/PromptDialog.cs`) to collect it before running. Every "Apply"
operation checks the allowable range first: if the new value stays inside
it, the existing optimal basis is reused directly (fast, no re-solve, and
mathematically exact); if the change falls outside the range, the model is
automatically re-solved from scratch and the live log/result panel update
with the new answer.

One correctness detail worth calling out: constraint coefficients and RHS
values are internally sign-normalised (a row is multiplied by -1 if its RHS
was originally negative, so the initial basis is always a clean identity
matrix). Every ranging calculation corrects for this automatically
(`SimplexTableau.RowSign`) so the ranges reported are always with respect to
the value the user actually typed, not the internally-flipped one.

## Non-linear objectives (e.g. f(x) = x²)

Out of scope for this build's focus area. Note for whoever implements it:
none of the algorithms above are applicable as-is, since Simplex-family
methods require a *linear* objective and constraints. A worked non-linear
example is normally solved outside the simplex framework entirely (e.g. by
evaluating the closed-form optimum, or a simple derivative-based/golden-section
search over a supplied range) and should be its own, clearly separate menu
path with its own explanation, exactly as the brief requires ("you need to
explain the code for this part").
